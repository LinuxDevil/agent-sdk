/**
 * Webhook trigger adapter (LOU-T5).
 *
 * Generalizes AgentSpec's existing `triggers` field (see
 * `AgentSpecTrigger` in src/spec/schema.ts, an open `{type, ...}` record
 * that a webhook-shaped trigger entry would use `type: 'webhook'` under)
 * into a real, runnable adapter: starts a plain Node `http` server, and on
 * each inbound POST request runs the agent and writes the result straight
 * back as the HTTP response.
 *
 * Reply semantics: the reply target IS the still-open HTTP response - no
 * separate `reply()` method is implemented (see types.ts's doc comment for
 * why this differs from Slack/cron).
 *
 * Authentication (LOU-D13): `options.auth` verifies every request (HMAC over
 * the raw body, bearer token, or a custom verifier) before the agent runs.
 *
 * LOU-P7: auth and input parsing are `webhookChannel()`'s (src/channels),
 * which this adapter delegates to; it keeps its own server and response.
 */
import * as http from 'node:http';
import type { ExecutionResult } from '../../execution/AgentExecutor';
import { Logger, noopLogger } from '../../execution/logger';
import { RunnableAgent, TriggerAdapter, TriggerContext, TriggerHandle } from '../types';
import type { WebhookAuth } from '../webhookAuth';
import { toChannelRequest } from '../../channels/defineChannel';
import { readRawBody, PayloadTooLargeError } from '../../server/chatRoutes';
import { webhookChannel, type WebhookChannel } from '../../channels/webhookChannel';
import { hostHeaderAllowed, isLoopbackHost } from '../../server/hostCheck';
import { SDKError } from '../../execution/errors';

/**
 * Options for {@link WebhookTriggerAdapter}.
 *
 * @deprecated Use webhookChannel() with mountChannels(); see docs/channels.md. Will be removed in a future major version.
 */
export interface WebhookTriggerAdapterOptions {
  /** Port to listen on. Defaults to 0 (OS-assigned ephemeral port - inspect `handle.port` after `listen()`). */
  port?: number;
  /**
   * Host to bind to. Defaults to `'127.0.0.1'` (this machine only). A
   * non-loopback host (e.g. `'0.0.0.0'`) needs `auth`, or
   * `allowUnauthenticated: true`.
   */
  host?: string;
  /** Only requests to this path are handled; everything else gets a 404. Defaults to '/'. */
  path?: string;
  /**
   * Authenticate every request (HMAC signature over the raw body, bearer
   * token, or a custom verifier). Failures get a generic `401`. Strongly
   * recommended for any webhook reachable from outside your machine.
   *
   * @example
   * ```ts
   * new WebhookTriggerAdapter({
   *   auth: { type: 'hmac', secret: process.env.WEBHOOK_SECRET ?? '' },
   * });
   * ```
   */
  auth?: WebhookAuth;
  /**
   * Listen on a non-loopback `host` without `auth`: anyone who can reach the
   * port can then run your agent. Default `false`, which makes the
   * constructor throw `LOUSHO_TRIGGER_INVALID` for that configuration.
   */
  allowUnauthenticated?: boolean;
  /** Receives auth failures and the "no auth configured" warning. Defaults to a no-op logger. */
  logger?: Logger;
}

/**
 * The handle {@link WebhookTriggerAdapter} returns from `listen()`.
 *
 * @deprecated Use webhookChannel() with mountChannels(); see docs/channels.md. Will be removed in a future major version.
 */
export interface WebhookTriggerHandle extends TriggerHandle {
  /** The actual port the server bound to (useful when `options.port` was 0/omitted). */
  readonly port: number;
}

const DEFAULT_HOST = '127.0.0.1';

function writeJson(res: http.ServerResponse, status: number, value: unknown): void {
  res.writeHead(status, { 'Content-Type': 'application/json' }).end(JSON.stringify(value));
}

type WebhookOnEvent = (input: string, context: TriggerContext) => Promise<ExecutionResult>;

interface WebhookRuntime {
  path: string;
  /** The bound host, and whether requests are authenticated: an open loopback listener refuses browser and rebound requests. */
  host: string;
  open: boolean;
  onEvent: WebhookOnEvent;
  channel: WebhookChannel;
  logger: Logger;
}

async function respondWithAgentResult(
  runtime: WebhookRuntime,
  req: http.IncomingMessage,
  res: http.ServerResponse
): Promise<void> {
  try {
    const request = toChannelRequest(req, await readRawBody(req));
    const { ok, reason } = await runtime.channel.verify(request);
    if (!ok) {
      runtime.logger.warn('webhook request rejected: authentication failed', { reason, remoteAddress: req.socket.remoteAddress });
      writeJson(res, 401, { error: 'Unauthorized' });
      return;
    }
    const inbound = await runtime.channel.parse(request);
    const input = typeof inbound?.input === 'string' ? inbound.input : '';
    const result = await runtime.onEvent(input, { channel: res, request: req });
    writeJson(res, 200, result);
  } catch (error) {
    if (error instanceof PayloadTooLargeError) {
      writeJson(res, 413, { error: 'Payload too large' });
      return;
    }
    // Never echo internal error messages to the (possibly unauthenticated) caller.
    runtime.logger.error('webhook request failed', { error: (error as Error).message });
    writeJson(res, 500, { error: 'Internal error' });
  }
}

async function handleWebhookRequest(
  runtime: WebhookRuntime,
  req: http.IncomingMessage,
  res: http.ServerResponse
): Promise<void> {
  if (req.method !== 'POST' || req.url !== runtime.path) {
    writeJson(res, 404, { error: 'Not found' });
    return;
  }
  // Without auth on loopback, a web page must not reach the agent: not through DNS rebinding (a foreign
  // `Host`) and not with a cross-site POST (a webhook sender sends no `Origin`).
  if (runtime.open && (!hostHeaderAllowed(req.headers.host, runtime.host) || req.headers.origin !== undefined)) {
    writeJson(res, 403, { error: 'Forbidden' });
    return;
  }
  await respondWithAgentResult(runtime, req, res);
}

/**
 * Runs an agent on each HTTP request to its own server and answers with the result.
 *
 * @deprecated Use webhookChannel() with mountChannels(); see docs/channels.md. Will be removed in a future major version.
 */
export class WebhookTriggerAdapter implements TriggerAdapter<http.ServerResponse> {
  public readonly type = 'webhook';

  private warnedUnauthenticated = false;

  private readonly channel: WebhookChannel;

  constructor(private readonly options: WebhookTriggerAdapterOptions = {}) {
    const host = options.host ?? DEFAULT_HOST;
    if (!options.auth && !options.allowUnauthenticated && !isLoopbackHost(host)) {
      throw new SDKError(
        `WebhookTriggerAdapter: refusing to listen on ${host} without \`auth\`: anyone who can reach it could run your agent. ` +
          "Configure options.auth (hmac, bearer or custom), bind '127.0.0.1', or pass allowUnauthenticated: true.",
        'LOUSHO_TRIGGER_INVALID'
      );
    }
    this.channel = webhookChannel({ auth: options.auth });
  }

  private warnIfUnauthenticated(host: string, logger: Logger): void {
    if (this.options.auth || this.warnedUnauthenticated || isLoopbackHost(host)) return;
    this.warnedUnauthenticated = true;
    logger.warn(
      `WebhookTriggerAdapter is listening on ${host} without \`auth\`: anyone who can reach it can run your agent. ` +
        'Configure options.auth (hmac, bearer or custom); see docs/triggers.md#webhook-authentication.'
    );
  }

  public listen(
    agent: RunnableAgent,
    onEvent: WebhookOnEvent
  ): WebhookTriggerHandle {
    const host = this.options.host ?? DEFAULT_HOST;
    const logger = this.options.logger ?? noopLogger;
    const open = !this.options.auth && isLoopbackHost(host);
    const runtime: WebhookRuntime = { path: this.options.path ?? '/', host, open, onEvent, channel: this.channel, logger };
    this.warnIfUnauthenticated(host, logger);

    const server = http.createServer((req, res) => {
      void handleWebhookRequest(runtime, req, res);
    });

    server.listen(this.options.port ?? 0, host);

    void agent; // available for adapters/callers that want a default onEvent; unused by this adapter's own logic.

    const handle: WebhookTriggerHandle = {
      get port(): number {
        const addr = server.address();
        return typeof addr === 'object' && addr ? addr.port : 0;
      },
      stop: () =>
        new Promise<void>((resolve, reject) => {
          server.close((err) => (err ? reject(err) : resolve()));
        }),
    };
    return handle;
  }
}
