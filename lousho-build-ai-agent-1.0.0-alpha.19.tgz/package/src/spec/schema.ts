/**
 * Declarative agent spec file format (LOU-H9).
 *
 * A plain-data description of an agent - name, prompt, provider, tool
 * names - that can be authored as YAML or JSON and turned into a live
 * agent via specToAgent(). The TS interface and the zod schema below are
 * kept in lockstep by hand (zod is already a project dependency; no
 * schema-to-type codegen is set up in this repo).
 */
import { z } from 'zod';
import { anyError, typeErrors, type SafeParser } from '../utils/zodCompat';
import type { McpApproval, McpToolFilter } from '../tools/mcp/McpToolLoader';
import type { RunLimits } from '../execution/budget';
import { guardrailEntrySchema, type AgentSpecGuardrail } from './guardrailOptions';

export interface AgentSpecProvider {
  type: string;
  model: string;
}

/** `policy.compaction` as an object: when to compact, as a fraction of the context window. */
export interface AgentSpecCompaction {
  thresholdPercent?: number;
}

export { SPEC_GUARDRAIL_NAMES, type AgentSpecGuardrail, type SpecGuardrailName } from './guardrailOptions';

/**
 * Optional cross-harness execution policy (LOU-J1+). The known fields below
 * are validated and compiled by specToAgent() (LOU-X5) into `createAgent()`
 * permissions, guardrails, limits, `askQuestion` and compaction. Other
 * fields stay an open record (`.passthrough()` on the zod side): different
 * target harnesses (Claude Code, Codex, Pi, ...) each honor a different
 * subset, and the generators read the raw policy.
 */
export interface AgentSpecPolicy {
  /** `true`: every tool call asks for approval. A list: only those tools do. */
  requiresApproval?: boolean | string[];
  /** Built-in guardrails (see {@link AgentSpecGuardrail}'s names, `SPEC_GUARDRAIL_NAMES`) on the agent's input and output. */
  guardrails?: AgentSpecGuardrail[];
  /** Budgets of each run (`createAgent({ limits })`). */
  limits?: RunLimits;
  /** Adds the built-in `ask_question` tool. */
  askQuestion?: boolean;
  /** `true` for the defaults, or `{ thresholdPercent }`. */
  compaction?: boolean | AgentSpecCompaction;
  /** Additional, harness-specific policy fields. */
  [key: string]: unknown;
}

/**
 * Optional trigger describing when/how this agent is invoked outside of a
 * direct call (e.g. a monitoring webhook, a cron schedule). Open record for
 * the same reason as AgentSpecPolicy above.
 */
export interface AgentSpecTrigger {
  type: string;
  [key: string]: unknown;
}

/** An MCP server launched as a child process and spoken to over stdio. */
export interface McpStdioServerSpec {
  command: string;
  args?: string[];
  env?: Record<string, string>;
  /** The process's working directory. Default: this process's. */
  cwd?: string;
  /**
   * The process's stderr: `'forward'` (default) copies it to this process's
   * stderr and keeps the last lines for a start failure (`LOUSHO_MCP_START_FAILED`);
   * `'capture'` only keeps them; `'inherit'` and `'ignore'` keep nothing.
   */
  stderr?: 'forward' | 'capture' | 'inherit' | 'ignore';
  /** Which of this server's tools ask for approval (LOU-Z5). Default `'always'` (Eve TOOLS-F11). */
  approval?: McpApproval;
  /** N2: withhold this server's tools from the model until `tool_search` finds them (docs/tool-search.md). */
  deferLoading?: boolean;
  /** How long one tool call may take, in milliseconds. Default: the MCP SDK's 60 seconds. */
  timeoutMs?: number;
  /** How long connecting (the `initialize` handshake) may take, in milliseconds. Default: the MCP SDK's 60 seconds. */
  connectTimeoutMs?: number;
  /** Load only some of this server's tools, by their MCP names: `{ include?, exclude? }`. */
  tools?: McpToolFilter;
  /**
   * A server that fails to connect is left out (with a warning) instead of
   * failing every run of the agent (`connectMcp()` skips it even with
   * `onError: 'throw'`). Default `false`. In `createAgent({ mcpServers })` its
   * tools then stay out for the life of the agent.
   */
  optional?: boolean;
}

/**
 * OAuth for an HTTP MCP server (N9c), per the MCP authorization spec: the SDK
 * discovers the authorization server, registers a client when no `clientId` is
 * given, and signs in with PKCE and a resource indicator. The grant belongs to
 * the app: an operator signs the agent in once (`agent.oauth.mcpSignInUrl()`).
 */
export interface McpOAuthOptions {
  /** The agent's callback URL, e.g. `https://agent.example.com/oauth/callback`. */
  redirectUri: string;
  /** A pre-registered client. Omitted: dynamic client registration (RFC 7591). */
  clientId?: string;
  /** The secret of a confidential pre-registered client. */
  clientSecret?: string;
  scopes?: readonly string[];
  /** Shown on the consent screen when registering. Default `'lousho'`. */
  clientName?: string;
}

/** An MCP server reached over HTTP. */
export interface McpHttpServerSpec {
  url: string;
  headers?: Record<string, string>;
  /** Which of this server's tools ask for approval (LOU-Z5). Default `'always'` (Eve TOOLS-F11). */
  approval?: McpApproval;
  /** N2: withhold this server's tools from the model until `tool_search` finds them (docs/tool-search.md). */
  deferLoading?: boolean;
  /** How long one tool call may take, in milliseconds. Default: the MCP SDK's 60 seconds. */
  timeoutMs?: number;
  /** How long connecting (the `initialize` handshake) may take, in milliseconds. Default: the MCP SDK's 60 seconds. */
  connectTimeoutMs?: number;
  /** Load only some of this server's tools, by their MCP names: `{ include?, exclude? }`. */
  tools?: McpToolFilter;
  /** Sign in to this server with OAuth (N9c); see {@link McpOAuthOptions}. */
  oauth?: McpOAuthOptions;
  /**
   * A server that fails to connect is left out (with a warning) instead of
   * failing every run of the agent (`connectMcp()` skips it even with
   * `onError: 'throw'`). Default `false`. In `createAgent({ mcpServers })` its
   * tools then stay out for the life of the agent.
   */
  optional?: boolean;
}

/**
 * One entry of `AgentSpec.mcpServers` (LOU-D20): stdio (`command`, optional
 * `args`/`env`) or HTTP (`url`, optional `headers`). Exactly one of
 * `command` / `url` is set.
 */
export type McpServerSpec = McpStdioServerSpec | McpHttpServerSpec;

export interface AgentSpec {
  name: string;
  prompt: string;
  provider: AgentSpecProvider;
  tools?: string[];
  /**
   * Optional (LOU-J1+, backward-compatible with LOU-H9's original
   * {name, prompt, provider, tools} shape - existing specs that omit this
   * still validate and load unchanged).
   */
  policy?: AgentSpecPolicy;
  /** Optional (LOU-J1+), same backward-compatibility note as `policy`. */
  triggers?: AgentSpecTrigger[];
  /**
   * Optional (LOU-D20), same backward-compatibility note as `policy`: MCP
   * servers this agent uses, keyed by a name that namespaces their tools.
   */
  mcpServers?: Record<string, McpServerSpec>;
}

const providerSchema = z.object({
  type: z.string(typeErrors({ required: "AgentSpec validation failed: missing required field 'provider.type'" })),
  model: z.string(typeErrors({ required: "AgentSpec validation failed: missing required field 'provider.model'" })),
});

const POLICY = 'AgentSpec validation failed:';

const posInt = z.number().int().positive();

const runLimitsSchema = z
  .object({
    maxTokens: posInt.optional(),
    maxInputTokens: posInt.optional(),
    maxOutputTokens: posInt.optional(),
    maxCostUsd: z.number().positive().optional(),
    maxDurationMs: posInt.optional(),
    maxSteps: posInt.optional(),
    onExceeded: z.enum(['stop', 'throw']).optional(),
  })
  .strict();

const policySchema = z
  .object({
    requiresApproval: z
      .union([z.boolean(), z.array(z.string().min(1))], anyError(`${POLICY} 'requiresApproval' must be true, false or a list of tool names`))
      .optional(),
    guardrails: z.array(guardrailEntrySchema).optional(),
    limits: runLimitsSchema.optional(),
    askQuestion: z.boolean().optional(),
    compaction: z
      .union(
        [z.boolean(), z.object({ thresholdPercent: z.number().gt(0).lte(1).optional() }).strict()],
        anyError(`${POLICY} 'compaction' must be a boolean or { thresholdPercent: 0-1 }`)
      )
      .optional(),
  })
  .passthrough();

const triggerSchema = z
  .object({
    type: z.string(typeErrors({ required: "AgentSpec validation failed: missing required field 'triggers[].type'" })),
  })
  .passthrough();

const MCP_PREFIX = 'AgentSpec validation failed:';

const mcpStringMap = (field: string) =>
  z.record(z.string(), z.string(), typeErrors({ invalid: `${MCP_PREFIX} '${field}' must be a map of string to string` }));

/** `approval`: a mode, or (in code, not YAML/JSON) a predicate over a tool's name, annotations and call arguments. */
const mcpApprovalSchema = z.union(
  [z.enum(['annotations', 'always', 'never']), z.custom<McpApproval>((value) => typeof value === 'function')],
  anyError(`${MCP_PREFIX} 'approval' must be 'annotations', 'always' or 'never'`)
);

const mcpOAuthText = (field: string) =>
  z.string(typeErrors({ invalid: `${MCP_PREFIX} 'oauth.${field}' must be a string` })).min(1, `${MCP_PREFIX} 'oauth.${field}' must not be empty`);

/** `oauth` of an HTTP entry (N9c). */
const mcpOAuthSchema = z
  .object(
    {
      redirectUri: z
        .string(typeErrors({ required: `${MCP_PREFIX} 'oauth.redirectUri' is required`, invalid: `${MCP_PREFIX} 'oauth.redirectUri' must be a string` }))
        .url(`${MCP_PREFIX} 'oauth.redirectUri' must be a valid URL`),
      clientId: mcpOAuthText('clientId').optional(),
      clientSecret: mcpOAuthText('clientSecret').optional(),
      scopes: z.array(z.string(), typeErrors({ invalid: `${MCP_PREFIX} 'oauth.scopes' must be a list of strings` })).optional(),
      clientName: mcpOAuthText('clientName').optional(),
    },
    typeErrors({ invalid: `${MCP_PREFIX} 'oauth' must be an object with 'redirectUri'` })
  )
  .strict()
  .refine((oauth) => oauth.clientSecret === undefined || oauth.clientId !== undefined, {
    message: `${MCP_PREFIX} 'oauth.clientSecret' needs 'oauth.clientId' (a pre-registered client)`,
  });

const mcpMilliseconds = (field: string) =>
  z
    .number(typeErrors({ invalid: `${MCP_PREFIX} '${field}' must be a number of milliseconds` }))
    .positive(`${MCP_PREFIX} '${field}' must be a positive number of milliseconds`)
    .finite(`${MCP_PREFIX} '${field}' must be a positive number of milliseconds`);

const mcpToolNames = (field: string) =>
  z.array(z.string(), typeErrors({ invalid: `${MCP_PREFIX} 'tools.${field}' must be a list of tool names` }));

/** `tools` of an entry: which of the server's tools to load. */
const mcpToolFilterSchema = z
  .object(
    { include: mcpToolNames('include').optional(), exclude: mcpToolNames('exclude').optional() },
    typeErrors({ invalid: `${MCP_PREFIX} 'tools' must be an object with 'include' and/or 'exclude'` })
  )
  .strict();

/** What is wrong with a loosely-parsed `mcpServers` entry, if anything. */
function mcpServerProblem(server: Record<string, unknown>): string | undefined {
  const stdio = server.command !== undefined;
  if (stdio === (server.url !== undefined)) {
    return stdio
      ? "set either 'command' (stdio) or 'url' (HTTP), not both"
      : "missing 'command' (stdio server) or 'url' (HTTP server)";
  }
  const stray = (stdio ? ['headers', 'oauth'] : ['args', 'env', 'cwd', 'stderr']).find((key) => server[key] !== undefined);
  return stray && `'${stray}' does not apply to ${stdio ? "a stdio ('command')" : "an HTTP ('url')"} server`;
}

/**
 * One `mcpServers` entry. A plain z.discriminatedUnion cannot word the
 * mix-ups well (neither/both of command and url, stdio-only fields on an HTTP
 * server and vice versa), so this validates a loose object and then narrows it
 * to McpServerSpec. Issue paths include the entry name (`mcpServers.fs.env`).
 */
const mcpServerSchema = z
  .object(
    {
      command: z
        .string(typeErrors({ invalid: `${MCP_PREFIX} 'command' must be a string` }))
        .min(1)
        .optional(),
      args: z
        .array(z.string(), typeErrors({ invalid: `${MCP_PREFIX} 'args' must be a list of strings` }))
        .optional(),
      env: mcpStringMap('env').optional(),
      url: z
        .string(typeErrors({ invalid: `${MCP_PREFIX} 'url' must be a string` }))
        .url(`${MCP_PREFIX} 'url' must be a valid URL`)
        .optional(),
      headers: mcpStringMap('headers').optional(),
      approval: mcpApprovalSchema.optional(),
      oauth: mcpOAuthSchema.optional(),
      deferLoading: z.boolean(typeErrors({ invalid: `${MCP_PREFIX} 'deferLoading' must be true or false` })).optional(),
      timeoutMs: mcpMilliseconds('timeoutMs').optional(),
      connectTimeoutMs: mcpMilliseconds('connectTimeoutMs').optional(),
      cwd: z.string(typeErrors({ invalid: `${MCP_PREFIX} 'cwd' must be a string` })).min(1).optional(),
      stderr: z
        .enum(['forward', 'capture', 'inherit', 'ignore'], anyError(`${MCP_PREFIX} 'stderr' must be 'forward', 'capture', 'inherit' or 'ignore'`))
        .optional(),
      tools: mcpToolFilterSchema.optional(),
      optional: z.boolean(typeErrors({ invalid: `${MCP_PREFIX} 'optional' must be true or false` })).optional(),
    },
    typeErrors({ invalid: `${MCP_PREFIX} each mcpServers entry must be an object with 'command' or 'url'` })
  )
  .superRefine((server, ctx) => {
    const problem = mcpServerProblem(server);
    if (problem) {
      ctx.addIssue({ code: z.ZodIssueCode.custom, message: `${MCP_PREFIX} ${problem}` });
    }
  })
  // superRefine has verified exactly one of command/url and no cross-shape fields.
  .transform((server): McpServerSpec => server as McpServerSpec);

/** Also accepts the pre-LOU-D20 list form `[{ name, command | url }]` that `lousho doctor` read. */
const mcpServersSchema = z.preprocess(
  (value) =>
    Array.isArray(value)
      ? Object.fromEntries(
          value.map((entry: unknown, index) => {
            const { name, ...rest } = (entry ?? {}) as Record<string, unknown>;
            return [typeof name === 'string' ? name : `#${index + 1}`, rest];
          })
        )
      : value,
  z.record(z.string(), mcpServerSchema, typeErrors({ invalid: `${MCP_PREFIX} 'mcpServers' must be a map of server name to config` }))
);

const specSchema = z.object({
  name: z.string(typeErrors({ required: "AgentSpec validation failed: missing required field 'name'" })),
  prompt: z.string(typeErrors({ required: "AgentSpec validation failed: missing required field 'prompt'" })),
  provider: providerSchema,
  tools: z.array(z.string()).optional(),
  policy: policySchema.optional(),
  triggers: z.array(triggerSchema).optional(),
  mcpServers: mcpServersSchema.optional(),
});

/**
 * The spec schemas as published: structural types, not zod's, so their
 * declarations do not depend on the installed zod major (LOU-V4.2). `safeParse`
 * and `parse` work as on a zod schema.
 */
export interface SpecSchema<T> extends SafeParser<T> {
  parse(value: unknown): T;
}

/** {@link SpecSchema} of an object schema, with its `shape` (the spec's field names). */
export interface SpecObjectSchema<T> extends SpecSchema<T> {
  readonly shape: Readonly<Record<string, unknown>>;
}

export const agentSpecProviderSchema = providerSchema as unknown as SpecSchema<AgentSpecProvider>;
export const agentSpecPolicySchema = policySchema as unknown as SpecSchema<AgentSpecPolicy>;
export const agentSpecTriggerSchema = triggerSchema as unknown as SpecSchema<AgentSpecTrigger>;
export const mcpServerSpecSchema = mcpServerSchema as unknown as SpecSchema<McpServerSpec>;
export const agentSpecSchema = specSchema as unknown as SpecObjectSchema<AgentSpec>;
