/**
 * Build AI Agent SDK
 * Framework-agnostic SDK for building AI agents
 * 
 * @packageDocumentation
 */

// Version
export { VERSION } from './version';

// A3: the executor API (AgentBuilder, AgentExecutor, resume functions,
// ToolRegistry) moved to '@lousho/build-ai-agent/executor'.

// Type exports
export * from './types';

// Tools (ToolRegistry moved to '@lousho/build-ai-agent/executor' (A3))
export * from './tools/rootTools';

// Flows moved to '@lousho/build-ai-agent/flows' (A1).



// Providers
export * from './providers';

// Execution
export * from './execution';

// Evals
export * from './evals';

// Security
export * from './security';

// Storage moved to '@lousho/build-ai-agent/utils' (A1).


// Token estimation and model registry (LOU-W1)
export * from './models';

// Context compaction (LOU-W2)
export * from './context';

// Utils: the error helpers stay on the root; encryption, StorageService and
// the validators moved to '@lousho/build-ai-agent/utils' (A1).
export * from './utils/errors';
export * from './utils/errorCodes';

// createAgent() convenience API (LOU-H1)
export * from './createAgent';
// LOU-R27: also named-re-exported explicitly. Under true-ESM importers that
// consume the TypeScript source through a CJS interop layer (.mts via tsx),
// `export *` barrels are not statically resolvable and their names fail with
// "does not provide an export named 'createAgent'"; an explicit named
// re-export is seen by cjs-module-lexer and imports fine. The bundled dist
// entries are unaffected either way.
export { createAgent } from './createAgent';
// Handoffs: hand the conversation to another agent (N6)
export * from './handoffs';
// Who is calling (N10a): the helpers live in '@lousho/build-ai-agent/auth'; the type rides in SendOptions.
export type { Principal } from './auth/types';
export type { AgentApprovals, ApproveToolCall, ResolveApprovalOptions } from './createAgentApprovals';
export type { PendingRun } from './agentPending';
// One store for sessions, checkpoints and approvals: createAgent({ store }) (LOU-D30)
export { memoryStore, type AgentStore, type MemoryStoreOptions } from './storage/agentStore';
export { fileStore, type FileStore, type FileStoreOptions, type FileStorePruneOptions, type FileStorePruneResult } from './storage/fileStore';
// OAuth token storage: AgentStore.tokens (N9a)
export * from './oauth';

// Sessions: multi-turn conversations for createAgent() (LOU-W4)
export * from './session';

// AGENTS.md / CLAUDE.md auto-loading (LOU-W7)
export * from './projectInstructions';

// Skills: progressive disclosure of instructions (LOU-Y2)
export * from './skills';

// Memory slots: scoped long-term memory for createAgent() (LOU-W6)
export * from './memory';
// kvMemory(): a memory provider bound to the Worker's KV namespace at request
// time, for the memory/ files of a cloudflare-worker agent directory (#298).
export { kvMemory, type KVMemoryOptions } from './deploy/workerMemory';

// Sub-agents: the `subagents` option and its `task` tool (LOU-Y3)
export * from './subagents';

// Filesystem agent loader: an agent as a directory (LOU-Y5)
export * from './agentDir';

// Claude-Code-compatible project context (CLAUDE.md, .claude/{skills,agents,rules,scratchpad})
export * from './claude';

export * from './decisions';

// Schedules: defineSchedule() and startSchedules() (LOU-P8)
export * from './schedules';

// Channels: inbound surfaces mapped to sessions, replies back to the surface (LOU-P7)
export * from './channels';

// Agent Client Protocol server for editors such as Zed (`lousho acp`, LOU-Z6)
export { serveAcp, type ServeAcpOptions } from './acp/serveAcp';

// Declarative agent spec file format (LOU-H9)
export * from './spec';

// Deployment adapter registry (LOU-I1). Only the interface + registry are
// exported here; the built-in adapters (node-server, cloudflare-worker,
// docker) are wired up by the `lousho build` CLI (src/cli/build.ts).
export * from './deploy/types';

// AI SDK UI stream adapter (LOU-P1): Fetch/Worker-safe, no node:* imports.
export * from './server/uiMessageStream';

// Route handler for Next.js and other Fetch-API frameworks (LOU-P4).
export * from './server/routeHandler';
