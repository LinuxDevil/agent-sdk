/**
 * `lousho doctor [agent.yaml|json] [--json] [--ping]` - first-run diagnostic.
 *
 * Thin wrapper over the pure core in doctorCore.ts: builds the real
 * DoctorEnvironment (process, fs, module resolution, fetch, Docker),
 * renders the report and returns the exit code (1 if any check failed).
 */
import * as fs from 'node:fs';
import { createRequire } from 'node:module';
import * as path from 'node:path';
import { MissingPeerDependencyError, loadOptionalPeer } from '../providers/optionalPeer';
import { findSdkRoot } from '../deploy/bundle';
import { loadSpec } from '../spec/loadSpec';
import { resolveAgentDir } from '../agentDir';
import { resolveSpecTool } from '../spec/specToAgent';
import { exitCodeFor, parseCommand, type CommandSpec } from './args';
import { runDoctor } from './doctorCore';
import { renderJson, renderReport } from './doctorRender';
import type { DoctorEnvironment, SdkManifest } from './doctorTypes';

const DOCKER_TIMEOUT_MS = 2000;

export interface DoctorArgs {
  specPath?: string;
  json: boolean;
  /** `--ping`: GET `<base>/models` for each configured provider. */
  ping?: boolean;
  /** `-h` / `--help` was given: print the usage, run nothing. */
  help?: boolean;
}

const USAGE = 'Usage: lousho doctor [agent.yaml|json|agent-dir] [--json] [--ping]';

const HELP = `${USAGE}

Checks Node, the SDK's peer packages, provider API keys and, given a path, an agent spec or agent directory.
Prints a fix for every problem; exits 1 when a check fails. ./.env is loaded when it exists.

Options:
  --json      print the report as JSON
  --ping      also check that each configured provider endpoint answers
  -h, --help  show this help`;

const SPEC: CommandSpec = {
  command: 'doctor',
  usage: USAGE,
  positionals: 1,
  options: { json: { type: 'boolean' }, ping: { type: 'boolean' } },
};

/** Parses `lousho doctor` arguments; throws `LOUSHO_CONFIG_INVALID` for an unknown flag or a second path. */
export function parseDoctorArgs(argv: string[]): DoctorArgs {
  const { values, positionals, help } = parseCommand(SPEC, argv);
  return { specPath: positionals[0], json: values.json === true, ping: values.ping === true || undefined, help: help || undefined };
}

/** Walks up from a resolved entry file to the package.json named `name`. */
function findPackageJson(entry: string, name: string): string | null {
  for (let dir = path.dirname(entry); dir !== path.dirname(dir); dir = path.dirname(dir)) {
    const candidate = path.join(dir, 'package.json');
    if (fs.existsSync(candidate) && JSON.parse(fs.readFileSync(candidate, 'utf8')).name === name) {
      return candidate;
    }
  }
  return null;
}

/** Version of `name` as Node would resolve it from `cwd`, or null when it is not installed. */
function resolveVersion(cwd: string, name: string): string | null {
  const require = createRequire(path.join(cwd, 'noop.js'));
  // The first specifier can land on a nested package.json (the MCP SDK's exports map sends
  // `<name>/package.json` to dist/cjs/package.json), so walk up to the manifest named `name`.
  // Not installed, or "exports" hides both specifiers: null.
  for (const specifier of [`${name}/package.json`, name]) {
    try {
      const manifest = findPackageJson(require.resolve(specifier), name);
      if (manifest) return JSON.parse(fs.readFileSync(manifest, 'utf8')).version;
    } catch {
      // try the next specifier
    }
  }
  return null;
}

function commandExists(command: string, env: NodeJS.ProcessEnv): boolean {
  if (/[\\/]/.test(command)) return fs.existsSync(command);
  const extensions = process.platform === 'win32' ? (env.PATHEXT ?? '.EXE;.CMD;.BAT').split(';') : [''];
  const dirs = (env.PATH ?? '').split(path.delimiter).filter(Boolean);
  return dirs.some((dir) =>
    ['', ...extensions].some((ext) => fs.existsSync(path.join(dir, command + ext)))
  );
}

async function dockerReachable(): Promise<boolean> {
  let Docker: typeof import('dockerode');
  try {
    Docker = (await loadOptionalPeer('dockerode', () => import('dockerode'))).default;
  } catch (error) {
    // Without the optional dockerode peer there is no way to ask; its own check reports that.
    if (error instanceof MissingPeerDependencyError) return false;
    throw error;
  }
  const ping = new Docker().ping().then(() => true);
  const timeout = new Promise<boolean>((resolve) => setTimeout(() => resolve(false), DOCKER_TIMEOUT_MS).unref());
  return Promise.race([ping, timeout]);
}

function readSdkManifest(): SdkManifest {
  return JSON.parse(fs.readFileSync(path.join(findSdkRoot(), 'package.json'), 'utf8'));
}

/** The real DoctorEnvironment for the current process. */
export function buildEnvironment(args: DoctorArgs, cwd: string = process.cwd()): DoctorEnvironment {
  const resolveSpecFile = (file: string) => path.resolve(cwd, file);
  return {
    nodeVersion: process.versions.node,
    env: process.env,
    sdk: readSdkManifest(),
    resolvePackageVersion: (name) => resolveVersion(cwd, name),
    specPath: args.specPath ? resolveSpecFile(args.specPath) : undefined,
    isDirectory: (file) => fs.existsSync(file) && fs.statSync(file).isDirectory(),
    loadAgentDir: async (dir) => {
      const { config, manifest } = await resolveAgentDir(dir);
      return { name: manifest.name, model: typeof config.model === 'string' ? config.model : undefined, tools: manifest.tools };
    },
    loadSpec,
    resolveTool: resolveSpecTool,
    commandExists: (command) => commandExists(command, process.env),
    fetch: (url, init) => fetch(url, init),
    dockerReachable,
  };
}

/** Runs the command and prints the report; resolves to the process exit code. */
export async function runDoctorCommand(
  argv: string[],
  env?: DoctorEnvironment,
  write: (text: string) => void = (text) => console.log(text)
): Promise<number> {
  let args: DoctorArgs;
  try {
    args = parseDoctorArgs(argv);
  } catch (error) {
    console.error(error instanceof Error ? error.message : String(error));
    return exitCodeFor(error);
  }
  if (args.help) {
    write(HELP);
    return 0;
  }
  const report = await runDoctor(env ?? buildEnvironment(args), { ping: args.ping });
  const color = process.stdout.isTTY === true && !process.env.NO_COLOR;
  write(args.json ? renderJson(report) : renderReport(report, { color }));
  return report.exitCode;
}
