/**
 * `lousho dev` - a local dev server for iterating on an agent (LOU-H6).
 *
 * Serves:
 *   GET  /health  -> 200 'ok'
 *   GET  /        -> the minimal chat UI (LOU-H7)
 *   /chat routes  -> sessions, SSE streaming and approvals (LOU-D32), shared with
 *                    the deployed node server: see src/server/chatRoutes.ts
 *
 * Config loading (LOU-H9): configPath is a declarative agent spec file
 * (.yaml/.yml or .json - see src/spec/schema.ts's AgentSpec), loaded and
 * zod-validated via loadSpec() and turned into a live agent via
 * specToAgent(). This retrofits LOU-H6's original ad-hoc
 * {name, prompt, provider, tools} JSON loader now that LOU-H9 (the
 * designed-for successor) exists - the two shapes are compatible (a plain
 * .json config in the old shape is a valid AgentSpec), so no existing
 * configs need to change.
 *
 * Targets (LOU-D31): the path may also be an agent directory (loadAgentDir)
 * or a .ts/.js module exporting a SimpleAgent / createAgent() config; see
 * devReload.ts for detection, watching and the reload swap.
 */
import * as http from 'node:http';
import * as fs from 'node:fs';
import * as path from 'node:path';
import { handleChatRequest, sendJson, sendText, type ChatRoutesContext } from '../server/chatRoutes';
import { continueChannelSignIn } from '../channels/mountChannels';
import { fileTraceExporter } from '../traces';
import { DEFAULT_TRACE_DIR } from '../traces/format';
import { findSdkRoot } from '../deploy/bundle';
import { moduleDir } from '../utils/moduleDir';
import { exitCodeFor, parseCommand, portValue, stringValue, takeOptionalValueFlag, usageError, type CommandSpec } from './args';
import { detectTarget, hasOwnStore, startReloader, type DevOptions, type DevState } from './devReload';
import { hostHeaderAllowed, isLoopbackHost } from '../server/hostCheck';

export type { DevOptions } from './devReload';

export interface DevServerHandle {
  server: http.Server;
  port: number;
  close: () => Promise<void>;
}

/** src/cli/dev-ui next to the source, or dist/cli/dev-ui (copied there by the build) for a bundled chunk anywhere under dist/. */
function devUiPath(): string {
  const beside = path.join(moduleDir(), 'dev-ui', 'index.html');
  return fs.existsSync(beside) ? beside : path.join(findSdkRoot(), 'dist', 'cli', 'dev-ui', 'index.html');
}

function serveChatUi(res: http.ServerResponse): void {
  const html = fs.readFileSync(devUiPath(), 'utf8');
  res.writeHead(200, { 'Content-Type': 'text/html' });
  res.end(html);
}

/**
 * Mutable holder for the currently-loaded agent (LOU-H8), so /chat always
 * reads the latest reloaded version without restarting the HTTP server or
 * dropping connections.
 */
type AgentHolder = DevState;

type RouteHandler = (req: http.IncomingMessage, res: http.ServerResponse, holder: AgentHolder) => void;

function handleChatUi(_req: http.IncomingMessage, res: http.ServerResponse): void {
  try {
    serveChatUi(res);
  } catch {
    sendText(res, 404, 'dev UI not found');
  }
}

function handleStatus(_req: http.IncomingMessage, res: http.ServerResponse, holder: AgentHolder): void {
  const { target, reloads, error } = holder;
  sendJson(res, 200, { kind: target.kind, path: target.path, reloads, error: error ?? null });
}

const ROUTES = new Map<string, RouteHandler>([
  ['GET /health', (_req, res) => sendText(res, 200, 'ok')],
  ['GET /dev/status', handleStatus],
  ['GET /', handleChatUi],
]);

/** Where the server listens and which extra `Host` names it accepts. */
interface DevAccess {
  host: string;
  allowedHosts?: string[];
}

/**
 * The dev server is open and shows raw errors, so a web page must not reach it
 * through DNS rebinding: only loopback names (and, off loopback, IP addresses
 * and the bound host), plus `allowedHosts`, are served. A channel that
 * verifies its requests (a signature, a token) is reached through tunnels
 * under their own names, so it is not checked; one without `verify` is.
 */
function hostForbidden(req: http.IncomingMessage, pathname: string, access: DevAccess, holder: AgentHolder): boolean {
  const channel = /^\/channels\/([^/]+)/.exec(pathname)?.[1];
  if (pathname === '/health' || (channel !== undefined && holder.verifiedChannels?.has(channel))) return false;
  const host = req.headers.host;
  return !hostHeaderAllowed(host, access.host) && !(access.allowedHosts && hostHeaderAllowed(host, access.host, access.allowedHosts));
}

async function handleRequest(req: http.IncomingMessage, res: http.ServerResponse, holder: AgentHolder, access: DevAccess): Promise<void> {
  const { pathname } = new URL(req.url ?? '/', 'http://localhost');
  if (hostForbidden(req, pathname, access, holder)) {
    return sendJson(res, 403, { error: `Host "${req.headers.host ?? ''}" is not allowed. Pass --allowed-hosts to accept it.`, code: 'LOUSHO_REQUEST_FORBIDDEN' });
  }
  const handler = ROUTES.get(`${req.method} ${pathname}`);
  if (handler) return handler(req, res, holder);
  if (await holder.channels?.(req, res)) return;
  const chat: ChatRoutesContext = {
    name: 'lousho dev',
    agent: () => holder.agent,
    // A1: a local dev server shows the developer the provider's own error text.
    exposeErrors: true,
    // The dev store keeps sessions across reloads, unless the agent brought its own.
    session: (agent, id) => agent.session(hasOwnStore(agent) ? { id } : { id, store: holder.store }),
    // N9b: a channel turn paused on a sign-in continues on its surface after the callback.
    afterSignIn: (result) => continueChannelSignIn(holder.channels, result),
  };
  if (!(await handleChatRequest(req, res, chat))) sendText(res, 404, 'not found');
}

function createDevHttpServer(holder: AgentHolder, access: DevAccess): http.Server {
  return http.createServer((req, res) => {
    handleRequest(req, res, holder, access).catch((error) => {
      console.error('[lousho dev] unhandled request error:', error);
      if (!res.headersSent) {
        res.writeHead(500);
      }
      res.end();
    });
  });
}

function listenOnPort(server: http.Server, port: number, host: string): Promise<void> {
  return new Promise<void>((resolve, reject) => {
    const onError = (err: NodeJS.ErrnoException) => {
      server.removeListener('listening', onListening);
      if (err.code === 'EADDRINUSE') {
        reject(new Error(`[lousho dev] port ${port} is already in use. Pass a different port.`));
      } else {
        reject(err);
      }
    };
    const onListening = () => {
      server.removeListener('error', onError);
      resolve();
    };
    server.once('error', onError);
    server.once('listening', onListening);
    server.listen(port, host);
  });
}

/**
 * Starts the dev server, binding to `host`:`port` (checked for availability
 * up front - EADDRINUSE is caught and rejected with a clear, port-naming
 * error rather than crashing uncaught).
 *
 * `host` defaults to '127.0.0.1' (localhost-only) since this is a local dev
 * tool and should not be reachable from the network by default. Pass an
 * explicit host (e.g. '0.0.0.0') to opt in to LAN access, such as testing
 * from a phone on the same network.
 *
 * `configPath` is a spec file, an agent directory or a .ts/.js agent module
 * (detected by path type and extension, see `detectTarget`). Its sources are
 * watched (LOU-H8, LOU-D31): on a valid edit the live agent is swapped
 * in-place through the mutable AgentHolder above and the previous agent is
 * closed; on an invalid edit the error is logged and shown in the chat UI,
 * and the previous working agent is kept - the server never crashes and never
 * drops the port on a bad edit.
 */
export async function startDevServer(
  configPath: string,
  port = 3737,
  host = '127.0.0.1',
  options: DevOptions = {}
): Promise<DevServerHandle> {
  const reloader = await startReloader(detectTarget(configPath), options);
  const server = createDevHttpServer(reloader.state, { host, allowedHosts: options.allowedHosts });
  try {
    await listenOnPort(server, port, host);
  } catch (error) {
    await reloader.close();
    throw error;
  }
  const warning = exposureWarning(host, port);
  if (warning) console.warn(warning);

  return {
    server,
    port,
    close: async () => {
      await reloader.close();
      await new Promise<void>((resolve, reject) => server.close((err) => (err ? reject(err) : resolve())));
    },
  };
}

const USAGE = 'Usage: lousho dev <spec.yaml|spec.json|agent-dir|agent.ts> [--port N] [--host H] [--allowed-hosts a,b] [--no-schedules] [--traces[=dir]]';

const HELP = `${USAGE}

Serves an agent with a local chat UI (GET /) and HTTP API, and reloads it when its files change.
The path is a spec file (.yaml/.yml/.json), an agent directory, or a .ts/.js module exporting an agent or createAgent() options.
./.env is loaded when it exists (variables already set win).

Options:
  --port N          port to listen on (default 3737)
  --host H          interface to bind (default 127.0.0.1; 0.0.0.0 exposes the agent, unauthenticated, to your network)
  --allowed-hosts a,b
                    extra Host names to serve (a tunnel's name), besides loopback names and, off loopback, IP addresses
  --no-schedules    do not start an agent directory's schedules
  --traces[=dir]    write local trace files (default .lousho/traces); view them with lousho traces
  -h, --help        show this help`;

const SPEC: CommandSpec = {
  command: 'dev',
  usage: USAGE,
  positionals: 1,
  options: { port: { type: 'string' }, host: { type: 'string' }, 'allowed-hosts': { type: 'string' }, 'no-schedules': { type: 'boolean' } },
};

export interface DevCliArgs {
  path: string;
  port: number;
  host: string;
  /** `--allowed-hosts a,b`: extra `Host` names to serve. */
  allowedHosts?: string[];
  /** `--no-schedules`: an agent directory's schedules are not started. */
  noSchedules?: boolean;
  /** `--traces` (the default dir) or `--traces=<dir>`: write local traces there. */
  traces?: string | true;
  /** `-h` / `--help` was given: print the usage, run nothing. */
  help?: boolean;
}

/** Parses the arguments after `dev`; throws `LOUSHO_CONFIG_INVALID` for a missing path, an unknown flag, a flag without its value or a bad port. */
export function parseDevArgs(rest: string[]): DevCliArgs {
  const { rest: flags, value: traces } = takeOptionalValueFlag(SPEC, rest, 'traces');
  const { values, positionals, help } = parseCommand(SPEC, flags);
  if (help) return { path: '', port: 3737, host: '127.0.0.1', help };
  if (positionals.length === 0) throw usageError(SPEC, 'a path is required (a spec file, an agent directory or a .ts/.js agent module).');
  const noSchedules = values['no-schedules'] === true || undefined;
  const allowedHosts = stringValue(values['allowed-hosts'])?.split(',').map((entry) => entry.trim()).filter(Boolean);
  return { path: positionals[0], port: portValue(SPEC, values.port, 3737), host: stringValue(values.host) ?? '127.0.0.1', ...(allowedHosts && { allowedHosts }), noSchedules, traces };
}

/** The warning `lousho dev --host <h>` prints for a host other machines can reach (the dev server has no auth). */
export function exposureWarning(host: string, port: number): string | undefined {
  if (isLoopbackHost(host)) return undefined;
  return (
    `lousho dev: warning: the dev server has no authentication and shows raw error messages, so anyone who can reach ${host}:${port} ` +
    'can use this agent and its tools, keys and files. Bind 127.0.0.1 unless you trust the network.'
  );
}

/** Runs `lousho dev` with the arguments after `dev`; resolves with the exit code once the server listens. */
export async function runDev(rest: string[]): Promise<number> {
  try {
    const args = parseDevArgs(rest);
    if (args.help) {
      console.log(HELP);
      return 0;
    }
    const options: DevOptions = { schedules: !args.noSchedules, ...(args.allowedHosts && { allowedHosts: args.allowedHosts }) };
    if (args.traces) {
      const dir = args.traces === true ? DEFAULT_TRACE_DIR : args.traces;
      options.overrides = { exporter: fileTraceExporter({ dir }) };
      console.log(`lousho dev: writing traces to ${dir} (they include prompt and tool content; see docs/observability.md#local-traces)`);
    }
    const handle = await startDevServer(path.resolve(args.path), args.port, args.host, options);
    console.log(`lousho dev: listening on http://${args.host}:${handle.port}`);
    return 0;
  } catch (error) {
    console.error(error instanceof Error ? error.message : String(error));
    return exitCodeFor(error);
  }
}
