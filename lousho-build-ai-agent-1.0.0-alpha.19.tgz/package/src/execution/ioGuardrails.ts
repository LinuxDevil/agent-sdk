/**
 * Input and output guardrails (LOU-X4): checks on a run's new user input,
 * its assistant text and its tool arguments. A failed check either stops the
 * run (`finishReason: 'guardrail'`) or rewrites the text. Separate from the
 * diff/patch gates in patchChecks.ts (the "patch checks" of A5).
 */

import type { GenerateResult, LLMProvider, Message } from '../providers';
import type { CallUsage } from '../models/usage';
import { textOf } from '../providers/content';
import { resolveProvider } from '../providers/resolveProvider';
import type { ExecuteOptions } from './AgentExecutor';
import { runEventsOf } from './agentRun';
import { SDKError } from './errors';
import { brandClass } from '../utils/brand';
import { SECRET_PATTERNS } from './secretPatterns';

/** What a guardrail checks: the new user input, the assistant text, or a tool call's arguments. */
export type IoGuardrailKind = 'input' | 'output' | 'tool';

/** What {@link IoGuardrail.check} is given. */
export interface IoGuardrailContext {
  kind: IoGuardrailKind;
  /** The user message's text, the assistant text, or (for `tool`) the arguments as JSON. */
  text: string;
  messages: readonly Message[];
  toolName?: string;
  args?: Record<string, unknown>;
  /** The run's signal, for a check that calls a model or a service. */
  signal?: AbortSignal;
}

/** The kinds of personal data `piiGuardrail()` looks for (N5a). */
export type PiiType = 'email' | 'phone' | 'credit-card' | 'iban' | 'us-ssn' | 'ip-address';

/** The categories `moderationGuardrail()` asks the model about (N5a). */
export type ModerationCategory = 'hate' | 'harassment' | 'self-harm' | 'sexual' | 'sexual-minors' | 'violence' | 'illicit';

/**
 * What tripped, as data (N5a): types, labels and offsets into the checked
 * `text`, never the matched text itself, so events, traces and logs do not
 * copy the personal data or the secret. Your own guardrails use `'custom'`.
 */
export type GuardrailTripInfo =
  | { category: 'pii'; matches: Array<{ type: PiiType; start: number; end: number }> }
  | { category: 'secret'; matches: Array<{ label: string; start: number; end: number }> }
  | { category: 'prompt-injection'; source: 'heuristic' | 'model'; signals: string[] }
  | { category: 'moderation'; categories: ModerationCategory[] }
  | { category: 'custom'; [key: string]: unknown };

/**
 * A passed check, or a failed one: `block` (default) stops the run, `rewrite`
 * replaces the text with `replacement`. `info` (optional) is copied to the trip.
 */
export type IoGuardrailResult =
  | { ok: true }
  | { ok: false; reason: string; action?: 'block' | 'rewrite'; replacement?: string; info?: GuardrailTripInfo };

/** One named input, output or tool guardrail. A check that throws fails the run. */
export interface IoGuardrail {
  name: string;
  check(ctx: IoGuardrailContext): IoGuardrailResult | Promise<IoGuardrailResult>;
  /**
   * N5b: on an `input` guardrail, run the check while the first model call is
   * already in flight instead of before it. The call's streamed output is
   * held until every parallel check passes; a trip cancels the call and ends
   * the run as a blocking trip would. Such a check cannot rewrite: a
   * `rewrite` result blocks. Ignored on `output` and `tools` guardrails.
   * Default `false`. See docs/guardrails.md.
   */
  runInParallel?: boolean;
}

/** `createAgent({ guardrails })` / `ExecuteOptions.guardrails`: each list runs in order. */
export interface AgentGuardrails {
  /** On each new user message, before the first model call. */
  input?: readonly IoGuardrail[];
  /** On the final assistant text (in a streamed run, on every step's text, before its `text.done`). */
  output?: readonly IoGuardrail[];
  /** On a tool call's arguments, after the permission rules (skipped on `deny`) and before `needsApproval`. */
  tools?: readonly IoGuardrail[];
  /** `'stop'` (default): `finishReason: 'guardrail'`. `'throw'`: reject with `GuardrailError`. */
  onTripped?: 'stop' | 'throw';
}

/** The guardrail that blocked (`result.guardrail`, `guardrail.tripped`) or rewrote (`guardrail.rewrote`). */
export interface GuardrailTrip {
  name: string;
  kind: IoGuardrailKind;
  reason: string;
  /** For a `tool` guardrail: the tool called. */
  toolName?: string;
  /** What tripped, when the guardrail says (the built-in starter set always does). */
  info?: GuardrailTripInfo;
}

/** Thrown when a guardrail blocks under `onTripped: 'throw'`; `guardrail` says which. */
export class GuardrailError extends SDKError {
  constructor(readonly guardrail: GuardrailTrip) {
    super(`Guardrail '${guardrail.name}' blocked the ${guardrail.kind}: ${guardrail.reason}`, 'LOUSHO_GUARDRAIL_TRIPPED');
    this.name = 'GuardrailError';
  }
}
brandClass(GuardrailError, 'GuardrailError');

/** The run options guardrails read (a sub-agent's tool call sees the inherited ones). */
type GuardrailRuntime = Pick<ExecuteOptions, 'guardrails' | 'signal'>;

/** Runs `guardrails` in order: the first block trips; a rewrite changes the text the next one sees. */
async function runChecks(
  options: GuardrailRuntime,
  guardrails: readonly IoGuardrail[],
  ctx: IoGuardrailContext
): Promise<{ text: string; rewritten: boolean } | { tripped: GuardrailTrip }> {
  let { text } = ctx;
  let rewritten = false;
  for (const guardrail of guardrails) {
    const result = await guardrail.check({ ...ctx, text, signal: options.signal });
    if (result.ok) continue;
    const trip: GuardrailTrip = {
      name: guardrail.name,
      kind: ctx.kind,
      reason: result.reason,
      ...(ctx.toolName && { toolName: ctx.toolName }),
      ...(result.info && { info: result.info }),
    };
    if (result.action !== 'rewrite') return { tripped: trip };
    text = result.replacement ?? '';
    rewritten = true;
    runEventsOf(options as ExecuteOptions)?.guardrail({ type: 'guardrail.rewrote', ...trip });
  }
  return { text, rewritten };
}

/** The new input: the user messages that end the transcript (over all `lists`), and the transcript. */
function newInput(lists: Message[][]): { entries: Array<{ list: Message[]; index: number; message: Message }>; messages: Message[] } {
  const all = lists.flatMap((list) => list.map((message, index) => ({ list, index, message })));
  const messages = all.map(({ message }) => message);
  let start = all.length;
  while (start > 0 && messages[start - 1].role === 'user') start--;
  return { entries: all.slice(start), messages };
}

/**
 * Input guardrails on the user messages that end the transcript (the new
 * input); rewrites them in place. N5b: `runInParallel` ones are left to
 * {@link startParallelInputGuardrails}.
 */
export async function checkInputGuardrails(options: GuardrailRuntime, lists: Message[][]): Promise<GuardrailTrip | undefined> {
  const guardrails = options.guardrails?.input?.filter((guardrail) => !guardrail.runInParallel);
  if (!guardrails?.length) return undefined;
  const { entries, messages } = newInput(lists);
  for (const { list, index, message } of entries) {
    const checked = await runChecks(options, guardrails, { kind: 'input', text: textOf(message), messages });
    if ('tripped' in checked) return checked.tripped;
    // A rewrite replaces the text; image and file parts stay.
    const parts = typeof message.content === 'string' ? [] : message.content.filter((part) => part.type !== 'text');
    if (checked.rewritten) list[index] = { ...message, content: parts.length ? [{ type: 'text', text: checked.text }, ...parts] : checked.text };
  }
  return undefined;
}

/**
 * N5b: the `runInParallel` input guardrails of a run, checking its new input
 * while the first model call is in flight. Internal.
 */
export interface ParallelInputCheck {
  /** Aborts on the first trip (reason: a {@link ParallelInputTripped}) or throw (reason: the error). */
  readonly signal: AbortSignal;
  /** `true` once every check passed; `false` on the first trip or throw. Never rejects. */
  readonly verdict: Promise<boolean>;
  /** The trip, once one happened. */
  readonly trip?: GuardrailTrip;
  /** The error a check threw, once one did (it fails the run). */
  readonly error?: unknown;
  /** The model's reply and its usage, when the call finished before the verdict (reported usage counts after a trip). */
  response?: { generated: GenerateResult; measured: CallUsage };
}

/** N5b: the abort reason of a model call a parallel input guardrail cancelled. */
class ParallelInputTripped extends Error {
  constructor(readonly trip: GuardrailTrip) {
    super(`Guardrail '${trip.name}' blocked the input while the model call was in flight: ${trip.reason}`);
    this.name = 'AbortError';
  }
}

/** N5b: the start of the reason a `runInParallel` guardrail's rewrite blocks with. */
export const PARALLEL_REWRITE_PREFIX = 'runInParallel guardrails cannot rewrite: ';

type MutableCheck = { -readonly [K in keyof ParallelInputCheck]: ParallelInputCheck[K] };

/**
 * N5b: starts the `runInParallel` input guardrails on the new input (the
 * user messages ending `messages`), all at once, on a snapshot: they never
 * change the transcript. `undefined` when there are none or there is no new
 * input. The first trip or throw aborts the returned signal (and the signal
 * the other checks were given) and settles the verdict.
 */
export function startParallelInputGuardrails(options: GuardrailRuntime, messages: readonly Message[]): ParallelInputCheck | undefined {
  const guardrails = options.guardrails?.input?.filter((guardrail) => guardrail.runInParallel);
  if (!guardrails?.length) return undefined;
  const { entries, messages: snapshot } = newInput([[...messages]]);
  if (entries.length === 0) return undefined;
  // The checks' signal: aborted by a trip, a throw, or the run's own signal (the verdict is then `false`, with that reason as `error`).
  const controller = new AbortController();
  const { signal } = controller;
  const gate: MutableCheck = { signal, verdict: Promise.resolve(true) };
  const settle = (outcome: { trip: GuardrailTrip } | { error: unknown }) => {
    if (signal.aborted) return;
    if ('trip' in outcome) gate.trip = outcome.trip;
    else gate.error = outcome.error;
    controller.abort('trip' in outcome ? new ParallelInputTripped(outcome.trip) : outcome.error);
  };
  const stopped = new Promise<void>((resolve) => signal.addEventListener('abort', () => resolve(), { once: true }));
  const runSignal = options.signal;
  const onRunAbort = () => settle({ error: runSignal?.reason });
  runSignal?.addEventListener('abort', onRunAbort, { once: true });
  if (runSignal?.aborted) onRunAbort();
  const checks = entries.flatMap(({ message }) =>
    guardrails.map((guardrail) =>
      (async () => {
        const result = await guardrail.check({ kind: 'input', text: textOf(message), messages: snapshot, signal });
        if (result.ok) return;
        const reason = result.action === 'rewrite' ? `${PARALLEL_REWRITE_PREFIX}${result.reason}` : result.reason;
        settle({ trip: { name: guardrail.name, kind: 'input', reason, ...(result.info && { info: result.info }) } });
      })().catch((error: unknown) => settle({ error }))
    )
  );
  gate.verdict = Promise.race([Promise.all(checks), stopped]).then(() => {
    runSignal?.removeEventListener('abort', onRunAbort);
    return !signal.aborted;
  });
  return gate;
}

/** Output guardrails on an assistant text: the text to keep, or the trip. */
export async function checkOutputGuardrails(
  options: GuardrailRuntime,
  text: string,
  messages: readonly Message[]
): Promise<{ text: string } | { tripped: GuardrailTrip }> {
  const guardrails = options.guardrails?.output;
  return guardrails?.length ? runChecks(options, guardrails, { kind: 'output', text, messages }) : { text };
}

/** Tool guardrails on a call's arguments: the (rewritten) arguments; throws `GuardrailError` on a block. */
export async function checkToolGuardrails(
  options: GuardrailRuntime,
  call: { toolName: string; args: Record<string, unknown>; messages: readonly Message[] }
): Promise<Record<string, unknown>> {
  const guardrails = options.guardrails?.tools;
  if (!guardrails?.length) return call.args;
  const checked = await runChecks(options, guardrails, { kind: 'tool', text: JSON.stringify(call.args), ...call });
  if ('tripped' in checked) throw new GuardrailError(checked.tripped);
  return checked.rewritten ? (JSON.parse(checked.text) as Record<string, unknown>) : call.args;
}

/** A sub-agent's guardrails: the parent's first, then its own. */
export function inheritGuardrails(parent?: AgentGuardrails, own?: AgentGuardrails): AgentGuardrails | undefined {
  if (!parent || !own) return parent ?? own;
  const both = (kind: 'input' | 'output' | 'tools') => [...(parent[kind] ?? []), ...(own[kind] ?? [])];
  return { input: both('input'), output: both('output'), tools: both('tools'), onTripped: parent.onTripped ?? own.onTripped };
}

/** Fails texts longer than `maxChars`. */
export function maxLengthGuardrail({ maxChars }: { maxChars: number }): IoGuardrail {
  return {
    name: 'max-length',
    check: ({ text }) => (text.length <= maxChars ? { ok: true } : { ok: false, reason: `${text.length} characters, over the ${maxChars} limit` }),
  };
}

/**
 * Fails texts matching `pattern` (default: the secret-scan patterns: private
 * keys, OpenAI-style and AWS keys). `action: 'rewrite'` replaces each match
 * with `replacement` (default `'[redacted]'`) instead of blocking.
 *
 * @example
 * ```ts
 * import { regexGuardrail } from '@lousho/build-ai-agent';
 *
 * const ssn = regexGuardrail({ name: 'ssn', pattern: /\b\d{3}-\d{2}-\d{4}\b/, action: 'rewrite' });
 * ```
 */
export function regexGuardrail(options: {
  name: string;
  pattern?: RegExp | readonly RegExp[];
  action?: 'block' | 'rewrite';
  replacement?: string;
}): IoGuardrail {
  const { name, pattern = SECRET_PATTERNS.map((p) => p.pattern), action = 'block', replacement = '[redacted]' } = options;
  const patterns = pattern instanceof RegExp ? [pattern] : pattern;
  return {
    name,
    check: ({ text }) => {
      const hit = patterns.find((p) => text.search(p) !== -1);
      if (!hit) return { ok: true };
      const redacted = patterns.reduce((out, p) => out.replace(new RegExp(p.source, p.flags.replace('g', '') + 'g'), replacement), text);
      return { ok: false, reason: `matched ${hit}`, action, replacement: redacted };
    },
  };
}

/** Fails texts that mention one of `topics` (case-insensitive keyword match). */
export function denyTopicsGuardrail({ topics }: { topics: readonly string[] }): IoGuardrail {
  return {
    name: 'deny-topics',
    check: ({ text }) => {
      const topic = topics.find((t) => text.toLowerCase().includes(t.toLowerCase()));
      return topic === undefined ? { ok: true } : { ok: false, reason: `mentions the denied topic '${topic}'` };
    },
  };
}

/**
 * Asks `model` (an `LLMProvider` or a `"provider/model"` spec) whether the
 * text follows `instruction`: one call per check; a reply starting with
 * `PASS` passes, anything else fails with the reply as the reason.
 */
export function llmJudgeGuardrail({ model, instruction, name = 'llm-judge' }: { model: LLMProvider | string; instruction: string; name?: string }): IoGuardrail {
  let provider: LLMProvider | undefined;
  return {
    name,
    async check({ kind, text, signal }) {
      provider ??= typeof model === 'string' ? resolveProvider(model) : model;
      const { text: verdict } = await provider.generate({
        messages: [
          { role: 'system', content: `${instruction}\n\nJudge the ${kind} below. Reply with PASS if it is acceptable, otherwise FAIL: <reason>.` },
          { role: 'user', content: text },
        ],
        signal,
      });
      const reply = verdict.trim();
      return /^pass\b/i.test(reply) ? { ok: true } : { ok: false, reason: reply.replace(/^fail:?\s*/i, '') || 'the judge did not pass it' };
    },
  };
}
