/**
 * Approval Gate
 * Types and storage for human-in-the-loop tool approval.
 */

import { Message, ToolCall } from '../providers';
import { AgentConfig } from '../types';
import { StorageService, readJSONAttachmentLocked } from '../storage/StorageService';
import type { RunUsage } from '../models/usage';
import type { AgentFingerprint } from './agentFingerprint';
import type { Principal } from '../auth/types';

/**
 * A tool call that is waiting on a human decision before it can execute.
 */
export interface PendingApproval {
  id: string;
  toolCallId: string;
  toolName: string;
  args: Record<string, unknown>;
  agentId?: string;
  createdAt: string;
  /**
   * TTL: when the pause stops being decidable, as an ISO-8601 string like
   * `createdAt`. Set from the run's `approvalTtlMs`, or from the `ttlMs` of
   * the `ask` permission rule that paused the call. A decision that arrives
   * after it - also from another process or after a restart - resolves the
   * pause as denied (the model gets a `kind: 'denied'` tool error whose
   * reason is 'approval expired'), never as a stale approval. Absent: the
   * approval never expires.
   */
  expiresAt?: string;
  /**
   * LOU-Y1: set when the call belongs to a sub-agent - the names of the
   * sub-agents it runs inside, outermost first (e.g. `['researcher']`).
   * Absent for the top-level agent's own tool calls.
   */
  subagentPath?: string[];
  /**
   * LOU-X9: what the pause asks the human for. `'question'` for a call of the
   * built-in `ask_question` tool (see `question`); absent for a tool call
   * waiting on approval.
   */
  kind?: ApprovalKind;
  /** LOU-X9: the question to show, when `kind` is `'question'`. */
  question?: ApprovalQuestion;
  /**
   * N9b: where to sign in, when `kind` is `'sign-in'`: the tool called
   * `ctx.getToken()` for a provider the user has no token for yet.
   */
  signIn?: ApprovalSignIn;
  /**
   * N10b: who the paused run acts for (docs/auth.md), so an `approve`
   * callback or a channel's `approvers` function can see whose call it is.
   * Absent for a run without a principal.
   */
  principal?: Principal;
  /**
   * A1: the `agent.session()` id the paused run belongs to, as
   * `agent.approvals.list()` / `get()` report it when this process ran (or
   * resumed) that session's turn. Absent for a run outside a session, and for
   * a pause loaded from the store that no session of this process has opened
   * yet. Never saved with the approval.
   */
  sessionId?: string;
}

/**
 * LOU-X9: what a pending approval asks for. Absent on a record means `'tool'`.
 * N9b: `'sign-in'` when a tool needs the user to sign in to an OAuth provider.
 */
export type ApprovalKind = 'tool' | 'question' | 'sign-in';

/** N9b: the sign-in a `kind: 'sign-in'` pause waits on. */
export interface ApprovalSignIn {
  /** The provider's `name` (its token store key). */
  provider: string;
  /** The provider's `displayName`, e.g. `'GitHub'`. */
  displayName?: string;
  /** The authorization URL to open (it carries the `state` and the PKCE challenge, never a secret). */
  url: string;
  /** Set once the provider redirected back with an error (the user declined): approving then cancels the call. */
  declined?: boolean;
}

/** LOU-X9: the question an `ask_question` call puts to the user. */
export interface ApprovalQuestion {
  text: string;
  /** Choices to offer, in order; the tool result's `option` is an index into them. */
  options?: string[];
  /** With `options`: `false` means the answer must be one of them. */
  allowFreeText?: boolean;
}

/** LOU-X9: the name of the built-in question tool (`askQuestionTool()`). */
export const ASK_QUESTION_TOOL_NAME = 'ask_question';

/**
 * TTL: whether `pending` passed its `expiresAt` deadline (never when it has
 * none). An expired record is still resolved - through
 * `agent.approvals.resolve()` or `resumeAfterApproval()` - but the decision
 * is then a denial, whatever it said.
 */
export function approvalExpired(pending: Pick<PendingApproval, 'expiresAt'>, now: number = Date.now()): boolean {
  if (pending.expiresAt === undefined) return false;
  const deadline = Date.parse(pending.expiresAt);
  return !Number.isNaN(deadline) && deadline <= now;
}

/**
 * LOU-X9: `pending` with `kind: 'question'` and its `question` filled in when
 * it is an `ask_question` call; any other record is returned as is.
 */
export function describeApproval(pending: PendingApproval): PendingApproval {
  if (pending.kind !== undefined || pending.toolName !== ASK_QUESTION_TOOL_NAME) return pending;
  const { question, options, allowFreeText } = pending.args;
  return {
    ...pending,
    kind: 'question',
    question: {
      text: String(question ?? ''),
      ...(Array.isArray(options) && { options: options.map(String) }),
      ...(typeof allowFreeText === 'boolean' && { allowFreeText }),
    },
  };
}

/**
 * A human decision resolving a PendingApproval. For a question (LOU-X9),
 * `approved: true` with the answer as `note` answers it; `approved: false`
 * declines to answer.
 */
export interface ApprovalDecision {
  id: string;
  approved: boolean;
  note?: string;
  /**
   * Eve TOOLS-F19: with `approved: true`, `'session'` approves later calls of
   * this tool with the same arguments in the same session (the same
   * transcript) without asking again - "don't ask again for this".
   */
  remember?: 'session';
  /**
   * Eve TOOLS-F19: with `approved: true`, approve with these arguments instead
   * of the model's ("approve with edits"). They are validated against the
   * tool's input schema first: invalid ones throw `LOUSHO_TOOL_ARGS_INVALID`
   * and leave the approval pending. The model's tool call in the transcript is
   * rewritten to them, so the model sees what ran. Not for a question, a
   * sign-in or a handoff; ignored with `approved: false`.
   */
  args?: Record<string, unknown>;
}

/**
 * Eve TOOLS-F19: decisions made by a non-human `approve` callback
 * (`createAgent({ approve })`). Their approval is not remembered by `once()`:
 * only a human's (or a `remember` decision's) is.
 */
const automaticDecisions = new WeakSet<ApprovalDecision>();

/** Eve TOOLS-F19: marks `decision` as made by an `approve` callback, not a human. */
export function markAutomaticDecision<T extends ApprovalDecision>(decision: T): T {
  automaticDecisions.add(decision);
  return decision;
}

/** Eve TOOLS-F19: whether `decision` was made by an `approve` callback (see {@link markAutomaticDecision}). */
export function isAutomaticDecision(decision: ApprovalDecision): boolean {
  return automaticDecisions.has(decision);
}

/**
 * Enough state to resume an AgentExecutor.execute() run once a
 * PendingApproval has been resolved.
 */
export interface ExecutionSnapshot {
  agent: AgentConfig;
  currentMessages: Message[];
  /** The call this record decides (Eve TOOLS-F12: one of `approvalGroup`, when the step paused on several). */
  pendingToolCall: PendingApproval;
  steps: number;
  /**
   * The sessionId the paused AgentExecutor.execute() run was using for
   * durable-execution checkpointing (LOU-C9/C10), if any. Recorded so that
   * resume.ts can proactively invalidate any stale checkpoint left behind
   * under this sessionId once the approval is resolved - a checkpoint
   * saved before the pause is stale by construction, since a pause always
   * happens before the paused tool's result (and thus the next checkpoint
   * write) exists. Undefined when the paused run wasn't using durable
   * execution at all.
   */
  sessionId?: string;
  /** Eve DUI-F5: the paused run's `contextSessionId` (a session turn's session id), what its tools see as `ctx.sessionId`. */
  contextSessionId?: string;
  /**
   * LOU-U7: the tool calls of the same model turn that come after the
   * paused one and have not run yet, in call order. `resumeAfterApproval()`
   * records the paused call's result (or rejection) and then runs these
   * through the normal batch path - they can run, fail validation, or pause
   * the run again on another approval. Absent on snapshots saved before
   * this field existed, which means "no remaining calls": any call of that
   * turn still without a result gets an error result saying it was not run,
   * so the transcript stays valid for the provider.
   */
  remainingToolCalls?: ToolCall[];
  /** Usage the paused run had spent (LOU-V5), so the resumed run continues its totals. */
  usage?: RunUsage;
  /**
   * LOU-Y1: set when the run paused because a sub-agent it called paused for
   * approval. `pendingToolCall` is then the sub-agent's call, and
   * `resumeAfterApproval()` re-enters the sub-agent instead of running a tool
   * of this run.
   */
  subagent?: SubagentSuspension;
  /**
   * LOU-W9.2: the fingerprint of the agent that paused (for a sub-agent's
   * nested snapshot, of that sub-agent). `resumeAfterApproval()` compares it
   * with the resuming agent's (`onAgentDrift`). Absent on older snapshots,
   * which resume without any check.
   */
  agentFingerprint?: AgentFingerprint;
  /**
   * N10b: who the paused run acts for. `resumeAfterApproval()` runs the
   * approved call and the rest of the run as this principal, whoever decides
   * (the decider is the approver, `ctx.approval.by`). Absent for a run without
   * one and on older snapshots (they resume with no principal).
   */
  principal?: Principal;
  /**
   * LOU-R16: the paused run's `ExecuteOptions.metadata`, so the resumed run's
   * hook contexts keep seeing it when the resuming call passes none. Absent
   * for a run without one and on older snapshots.
   */
  metadata?: Record<string, unknown>;
  /**
   * Eve TOOLS-F12: set when one model step paused on several calls at once -
   * every call of the step that waits on a decision, in call order, this
   * record's own (`pendingToolCall`) among them. Each has its own approval
   * record (the same snapshot with its own `pendingToolCall`); a decision is
   * written into the records still pending, and the step's calls run once the
   * last of them is decided. For a run paused on a sub-agent (`subagent`),
   * the sub-agent's group, as the lead's reviewers see it. Absent when the
   * step paused on one call.
   */
  approvalGroup?: ApprovalGroupMember[];
  /**
   * Eve TOOLS-F12: a sub-agent started by the same step that paused for
   * approval too. Once the step's own calls are decided (and ran), the run
   * pauses on it, as a run paused on a sub-agent (`subagent`). Absent when no
   * sub-agent of the step paused.
   */
  heldSubagent?: SubagentSuspension;
}

/** Eve TOOLS-F12: one call of a step paused on several approvals (see {@link ExecutionSnapshot.approvalGroup}). */
export interface ApprovalGroupMember {
  /** The paused call, as its own approval record holds it. */
  pending: PendingApproval;
  /** Set once the call is decided; it runs (or gets its rejection) when the whole step is decided. */
  decision?: GroupDecision;
}

/** Eve TOOLS-F12: a decision kept with a step's other pending calls until all of them are decided. */
export interface GroupDecision {
  /** `ApprovalDecision.approved` (false for an expired call). */
  approved: boolean;
  /** `ApprovalDecision.note`. */
  note?: string;
  /** `ApprovalDecision.remember`. */
  remember?: 'session';
  /** Approve-with-edits arguments, already validated. */
  args?: Record<string, unknown>;
  /** Decided by an `approve` callback, not a human (see {@link markAutomaticDecision}). */
  automatic?: true;
  /** TTL: the call's `expiresAt` had passed when it was decided, so it is denied as expired. */
  expired?: true;
  /** N10b: who decided (`ctx.approval.by`). */
  by?: Principal;
}

/**
 * Eve TOOLS-F12: `snapshot` as the record of group member `id` stores it: its
 * `pendingToolCall` is that member's call, also in the sub-agent's snapshot
 * it waits on (ids are shared across the levels of a sub-agent pause).
 */
export function snapshotForMember(snapshot: ExecutionSnapshot, id: string): ExecutionSnapshot {
  const member = snapshot.approvalGroup?.find((entry) => entry.pending.id === id);
  const subagent = snapshot.subagent && { ...snapshot.subagent, snapshot: snapshotForMember(snapshot.subagent.snapshot, id) };
  return { ...snapshot, ...(member && { pendingToolCall: member.pending }), ...(subagent && { subagent }) };
}

/**
 * Eve TOOLS-F12: `snapshot` with the decisions of `decided` (by id) written
 * into its group, and into the group of the sub-agent snapshot it waits on.
 */
export function withGroupDecisions(snapshot: ExecutionSnapshot, decided: ReadonlyMap<string, GroupDecision>): ExecutionSnapshot {
  const approvalGroup = snapshot.approvalGroup?.map((member) => {
    const decision = member.decision ?? decided.get(member.pending.id);
    return decision ? { ...member, decision } : member;
  });
  const subagent = snapshot.subagent && { ...snapshot.subagent, snapshot: withGroupDecisions(snapshot.subagent.snapshot, decided) };
  return { ...snapshot, ...(approvalGroup && { approvalGroup }), ...(subagent && { subagent }) };
}

/**
 * Eve TOOLS-F12: the records a pause saves - one per call of its group (each
 * with its own `pendingToolCall`), or `record` itself when the step paused on
 * one call. The group's first call comes first.
 */
export function approvalRecords(record: { pending: PendingApproval; snapshot: ExecutionSnapshot }): Array<{ pending: PendingApproval; snapshot: ExecutionSnapshot }> {
  const group = record.snapshot.approvalGroup;
  if (!group || group.length < 2) return [record];
  return group.map(({ pending }) => ({ pending, snapshot: snapshotForMember(record.snapshot, pending.id) }));
}

/**
 * A tool call of a paused run (a `task` or delegate tool call) whose
 * sub-agent is itself paused for approval. Plain data, so it is stored with
 * the rest of the snapshot.
 */
export interface SubagentSuspension {
  /** The parent's tool call that is waiting on the sub-agent. */
  toolCallId: string;
  toolName: string;
  args: Record<string, unknown>;
  /** The sub-agent's name. */
  agentName: string;
  /** The sub-agent's own paused run (which may itself wait on a sub-agent). */
  snapshot: ExecutionSnapshot;
  /**
   * M4: set when the suspended call is an `agent_await` waiting on background
   * sub-agent tasks paused for approval. Kept here, not in `args`, so the
   * model never sees it.
   */
  background?: SuspendedBackgroundTasks;
}

/** M4: the background tasks an `agent_await` call paused on (see {@link SubagentSuspension.background}). */
export interface SuspendedBackgroundTasks {
  /** The `task` call (`agent`, `prompt`, `description`) of the task this suspension pauses on (its run is `snapshot`). */
  task: Record<string, unknown>;
  /** The other awaited tasks still paused, in order: the run pauses on each in turn once this one is decided. */
  waiting: PausedBackgroundTask[];
}

/** M4: a background sub-agent task paused for approval, kept until an `agent_await` call resumes it. */
export interface PausedBackgroundTask {
  taskId: string;
  /** The `task` call that started it (`agent`, `prompt`, `description`). */
  task: Record<string, unknown>;
  /** The sub-agent's paused run. */
  snapshot: ExecutionSnapshot;
}

/**
 * A resolved approval record: the original pending tool call plus the
 * snapshot needed to resume execution.
 */
export interface ResolvedApproval {
  pending: PendingApproval;
  snapshot: ExecutionSnapshot;
}

/**
 * Persists PendingApprovals (and the ExecutionSnapshot needed to resume
 * them) so a paused agent run can survive a process restart.
 */
export interface ApprovalStore {
  save(pending: PendingApproval, snapshot: ExecutionSnapshot): Promise<void>;
  resolve(id: string): Promise<ResolvedApproval | null>;
  /**
   * The record `resolve(id)` would return, without claiming or deleting it:
   * `null` when `id` is unknown or already resolved. Optional (like
   * `CheckpointStore.history`): `agent.approvals.get()` reads a pause another
   * process saved only through it. All built-in stores implement it.
   */
  load?(id: string): Promise<ResolvedApproval | null>;
  /**
   * Eve TOOLS-F13: every approval the store holds that is not resolved yet,
   * oldest first (by `createdAt`) - the pending calls as they were saved,
   * without their snapshots. Optional: with it, `agent.approvals.list()` also
   * lists pauses saved by another process or before a restart. The file,
   * SQLite, KV (when the namespace binding has `list`) and in-memory stores
   * implement it.
   */
  list?(): Promise<PendingApproval[]>;
}

/** Eve TOOLS-F13: `pending`, oldest first by `createdAt` (ties keep their order). */
export function oldestFirst(pending: PendingApproval[]): PendingApproval[] {
  return pending
    .map((entry, index) => ({ entry, index, at: Date.parse(entry.createdAt) }))
    .sort((a, b) => (Number.isNaN(a.at) || Number.isNaN(b.at) || a.at === b.at ? a.index - b.index : a.at - b.at))
    .map(({ entry }) => entry);
}

/**
 * Default ApprovalStore backed by the SDK's StorageService.
 *
 * Follows the pattern StorageService documents and tests: acquireLock ->
 * read/write*JSON*Attachment -> releaseLock.
 */
export class StorageServiceApprovalStore implements ApprovalStore {
  constructor(private readonly storageService: StorageService) {}

  private getStorageKey(id: string): string {
    return `approvals/${id}.json`;
  }

  async save(pending: PendingApproval, snapshot: ExecutionSnapshot): Promise<void> {
    const storageKey = this.getStorageKey(pending.id);
    await this.storageService.acquireLock(storageKey);
    try {
      const record: ResolvedApproval = { pending, snapshot };
      this.storageService.writePlainJSONAttachment(storageKey, record);
    } finally {
      this.storageService.releaseLock(storageKey);
    }
  }

  async resolve(id: string): Promise<ResolvedApproval | null> {
    const storageKey = this.getStorageKey(id);
    // Delete-on-read, inside the same lock that guards the read.
    return readJSONAttachmentLocked<ResolvedApproval>(this.storageService, storageKey, () =>
      this.storageService.deleteAttachment(storageKey)
    );
  }

  async load(id: string): Promise<ResolvedApproval | null> {
    return readJSONAttachmentLocked<ResolvedApproval>(this.storageService, this.getStorageKey(id));
  }
}
