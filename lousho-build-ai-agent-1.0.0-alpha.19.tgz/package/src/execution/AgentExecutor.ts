/**
 * Agent Executor
 * Executes agents with streaming support and tool calling
 */

import type { Skill } from '../skills/defineSkill';
import { withSkills } from '../skills/withSkills';
import type { Subagents } from '../subagents/types';
import type { BackgroundTaskView } from '../subagents/backgroundTasks';
import { assertMaxSubagentDepth, withSubagents } from '../subagents/withSubagents';
import type { StandardSchemaV1 } from '../utils/zodCompat';
import { newId } from '../utils/id';
import { LLMProvider, Message, ToolCall, GenerateOptions, GenerateResult, ToolDefinition, type ReasoningOption, type ModelSettings, type RateLimiter, type PromptCachingOption } from '../providers';
import { AgentConfig } from '../types';
import { ToolRegistry } from '../tools';
import { SandboxAdapter, NoopSandbox } from '../security/sandboxCore';
import { ApprovalStore, approvalRecords, describeApproval, ExecutionSnapshot, PendingApproval, SubagentSuspension } from './ApprovalGate';
import { CheckpointStore, ForkOptions, ForkResult } from './checkpoint';
import type { AgentDriftMode } from './agentFingerprint';
import type { Principal } from '../auth/types';
import type { OAuthTokenStore } from '../oauth/types';
import { signInRequest } from '../oauth/signIn';
import { forkSession } from './fork';
import type { CallUsage, RunUsage, StepUsage } from '../models/usage';
import { attachRunUsage, mergeDelegatedUsage, recordStepUsage } from './runUsage';
import { TraceExporter, withSpan } from './tracing';
import {
  agentRunSpanInit,
  recordToolOutcome,
  resolveCaptureContent,
  toolSpanInit,
} from './genAiSpans';
import { HookRegistry } from './hooks';
import {
  baseAgentOf,
  extendAgent,
  settleSuspensions,
  suspensionRecord,
  type ToolCallScope,
} from './subagentRuntime';
import { ConfigurationError, isAbortError, isCassetteError, SDKError } from './errors';
import { abortReasonOf } from './abortReason';
import type { HostedTool } from '../tools/hosted';
import { assertHostedToolsSupported, countHostedCalls, withHostedCalls } from './hostedToolCalls';
import {
  PreparedToolCall,
  ToolCallContext,
  ToolCallOutcome,
  parseToolArguments,
  runToolCall,
} from './toolCallExecution';
import { resolveToolCallNames } from './toolNames';
import { assertMaxToolResultChars } from './toolResult';
import {
  StartedToolCall,
  ToolBatchResult,
  type UnrecordedToolCall,
  ToolConcurrency,
  assertToolConcurrency,
  runToolBatch,
} from './toolBatch';
import {
  compactGenerateError,
  GeneratedStep,
  generateInSpan,
  measureAbortedCall,
  prepareGenerateRequest,
  providerErrorMessage,
  shouldSurfaceToModel,
  sideGenerator,
} from './generateStep';
import {
  AgentRunState,
  assistantTurn,
  checkResumedAgent,
  ensureFingerprint,
  loadRunState,
  markRequestOnly,
  pushAbortedBatchResults,
  noteReasoning,
  pushToolResult,
  recordStep,
  saveStepCheckpoint,
  toExecutionResult,
} from './agentRunState';
import { acquireRunLease, HELD_RUN_LEASE, type RunLeaseOptions } from './runLease';

/** The largest time a `Date` can hold, in epoch ms. */
const MAX_DATE_MS = 8.64e15;
import { AgentRun, RUN_EVENTS, StreamingExecuteOptions, modelFinishReason, observeRun, partialSink, runEventsOf, startAgentRun } from './agentRun';
import type { AgentEvent } from './agentEvents';
import { withSteerSignal, type InputQueue } from './inputQueue';
import { assertOutputSchema, OutputError, outputInstruction, outputRepairMessage, truncatedOutput, validateOutput, type OutputSpec } from './structuredOutput';
import { PLAN_MODE_INSTRUCTION, permissionModeOf, type PermissionOptions } from './permissions';
import { assertToolSearchOptions, withToolSearch, type ToolSearchOptions } from './toolSearch';
import { withDeferral } from './toolDeferral';
import { RUN_CODE_TOOL, codeModeOf, nestedToolCaller, withCodeMode } from './codeMode';
import {
  BudgetExceeded,
  BudgetExceededError,
  RunBudget,
  RunLimits,
  SessionBudget,
  budgetOfAbort,
  assertMaxSteps,
  maxStepsOf,
  startBudget,
} from './budget';
import {
  GuardrailError,
  checkInputGuardrails,
  checkOutputGuardrails,
  startParallelInputGuardrails,
  type AgentGuardrails,
  type GuardrailTrip,
  type ParallelInputCheck,
} from './ioGuardrails';

import {
  cancelHandoffCalls,
  handOff,
  runTools,
  settleHonoredHandoff,
  splitHandoffCalls,
  takeHandoffCalls,
  type HandoffGate,
  type ResolvedHandoff,
} from './handoffRun';

export { PropagatingToolError } from './propagatingToolError';

/**
 * Why a run ended, as reported on `ExecutionResult.finishReason` and the
 * `finish` event. A closed union, so a typo does not compile (Eve CORE-F14).
 *
 * - `'stop'`, `'length'`, `'tool_calls'`, `'content_filter'`, `'error'`,
 *   `'other'`: the model's own finish reason for its last turn. A reason a
 *   provider reports outside this set is reported as `'other'`.
 * - `'awaiting-approval'`: paused on a tool call that needs a human
 *   decision (see `resumeAfterApproval()`).
 * - `'aborted'`: cancelled through `ExecuteOptions.signal` (LOU-V1).
 * - `'max-steps'`: the `maxSteps` budget ran out while the model still
 *   wanted to continue (LOU-U19). A run that finishes naturally within the
 *   budget keeps the model's own reason (usually `'stop'`).
 * - `'output-invalid'`: the run has an `output` schema and the final reply
 *   was still not valid JSON matching it after one repair step (LOU-V4);
 *   see `ExecutionResult.outputError`.
 * - `'budget-exceeded'`: a `limits` budget tripped (LOU-V6); see
 *   `ExecutionResult.budget`.
 * - `'guardrail'`: an input, output or tool guardrail blocked (LOU-X4); see
 *   `ExecutionResult.guardrail`.
 */
export type ExecutionFinishReason =
  | GenerateResult['finishReason']
  | 'awaiting-approval'
  | 'aborted'
  | 'max-steps'
  | 'output-invalid'
  | 'budget-exceeded'
  | 'guardrail';

/**
 * Execution options
 */
export interface ExecuteOptions extends PermissionOptions {
  agent: AgentConfig;
  input: string | Message[];
  provider: LLMProvider;
  /** The tools the run may call. Omitted: the run has no tools. */
  toolRegistry?: ToolRegistry;
  /**
   * N1a: tools the provider runs itself (`webSearch()`, `codeInterpreter()`,
   * `fileSearch()`, `hostedTool()`), sent with every model call of the run.
   * The run rejects with `LOUSHO_HOSTED_TOOL_UNSUPPORTED` when the provider
   * cannot send one (`provider.supportsHostedTool`). Their calls pass no
   * permission rule, guardrail, approval or hook: the provider runs them
   * inside the request. `createAgent()` sets this from `tools`.
   */
  hostedTools?: readonly HostedTool[];
  /**
   * Skills (LOU-Y2): instructions the model loads on demand. Their names and
   * descriptions are appended to the system prompt and a `load_skill` tool is
   * registered; bodies only enter the conversation when the model loads them.
   * Throws if a tool named `load_skill` is already registered.
   *
   * @example
   * AgentExecutor.execute({ agent, input, provider, skills: [defineSkill({ name, description, content })] });
   */
  skills?: readonly Skill[];
  /**
   * Sub-agents (LOU-Y3) this agent can delegate to: a record of
   * `createAgent()` agents keyed by name (each needs a `description`), or a
   * dynamic `{ list, resolve }` catalog (listed at the start of each run).
   * Registers ONE `task` tool (`{ agent, prompt, description }`) and lists the
   * sub-agents in the system prompt. A sub-agent sees only the `prompt`, and
   * inherits this run's signal, hooks, tracing, approval store,
   * `toolConcurrency` and event listeners (see docs/sub-agents.md). Throws
   * if a tool named `task` is already registered.
   *
   * @example
   * AgentExecutor.execute({ agent, input, provider, subagents: { researcher, writer } });
   */
  subagents?: Subagents;
  /**
   * How deep sub-agents may nest (LOU-Y3). Defaults to 1: the lead agent can
   * call sub-agents, but they cannot call sub-agents of their own. A run at
   * the limit is simply not offered the `task` tool. The top-level run's
   * value applies to the whole tree.
   */
  maxSubagentDepth?: number;
  /**
   * Span id to parent this run's `invoke_agent` span to (LOU-Y1). Set
   * automatically for a sub-agent, whose span becomes a child of the
   * parent's `execute_tool` span; set it yourself to nest a run inside your
   * own trace.
   */
  parentSpanId?: string;
  /**
   * @internal resumeAfterApproval(): the `invoke_agent` span it already opened
   * for this run (the approved tool ran inside it, before this call). The run
   * continues in that span instead of opening its own, and its owner ends it.
   */
  agentSpanId?: string;
  /** The most model calls the run makes before it ends with `finishReason: 'max-steps'`. */
  maxSteps?: number;
  /**
   * Eve CORE-F13: text appended to the system prompt of every model call of
   * this run (`send(msg, { instructions })`), after the agent's own
   * instructions. Sent with each request, never written to the transcript, so
   * a continued `sessionId` run gets it too and a checkpoint never keeps it.
   */
  appendInstructions?: string;
  /**
   * LOU-V6: token, cost, time and step budgets of this run, checked before
   * every model call and after one that asks for tools; `maxDurationMs` also
   * aborts in-flight calls. A tripped limit ends the run with
   * `finishReason: 'budget-exceeded'` and `result.budget` (or throws
   * `BudgetExceededError` with `onExceeded: 'throw'`). See docs/configuration.md#budgets.
   *
   * @example
   * ```ts
   * await AgentExecutor.execute({ agent, input: 'Research this', provider, limits: { maxCostUsd: 0.5, maxDurationMs: 60_000 } });
   * ```
   */
  limits?: RunLimits;
  /**
   * LOU-X4: input, output and tool guardrails. A block ends the run with
   * `finishReason: 'guardrail'` and `result.guardrail` (or throws
   * `GuardrailError` with `onTripped: 'throw'`); an input block makes no
   * model call. Sub-agents inherit them. See docs/guardrails.md.
   */
  guardrails?: AgentGuardrails;
  /** LOU-V6: a session's `limits` and what its earlier turns spent; set by `agent.session({ limits })`. */
  sessionBudget?: SessionBudget;
  /** Sent on every model call; wins over the same key in {@link ExecuteOptions.modelSettings}. */
  temperature?: number;
  /** Sent on every model call; wins over the same key in {@link ExecuteOptions.modelSettings}. */
  maxTokens?: number;
  /**
   * C6: sampling settings sent on every model call of the run (`maxTokens`,
   * `temperature`, `topP`, ...). A key left unset is not sent. Sub-agents
   * and handoff targets use their own. See docs/configuration.md#model-settings.
   */
  modelSettings?: ModelSettings;
  /**
   * Eve PROV-F14: queues every model call of the run, its sub-agents and its
   * handoff targets under one budget (`createRateLimiter()`; `createAgent({ rateLimit })` sets it).
   */
  rateLimiter?: RateLimiter;
  /**
   * LOU-D41: called with every {@link AgentEvent} of the run, synchronously
   * as it happens - the same events, in the same order, as `stream()`
   * yields, on `execute()` too. M9: with a listener, `execute()` streams each
   * model call when the provider can, so a step's text arrives as several
   * `text.delta` events, as on `stream()` (see {@link ExecuteOptions.streamModelCalls}).
   * Sub-agents' events arrive tagged with `subagent`. See docs/streaming.md#listening-without-iterating.
   *
   * @example
   * ```ts
   * await AgentExecutor.execute({ agent, input: 'Hi', provider, onAgentEvent: (event) => console.log(event.type) });
   * ```
   */
  onAgentEvent?: (event: AgentEvent) => void;
  /**
   * M9: whether a run with a listener (`onAgentEvent`) streams its
   * model calls through `provider.stream()` when the provider can, so each
   * step's text reaches the listeners as several `text.delta` events.
   * Default `true`; `false` generates each step whole (one `text.delta` per
   * step). Ignored by `stream()`, which always streams, and by a run without
   * listeners, which always generates.
   *
   * @example
   * ```ts
   * await AgentExecutor.execute({ agent, input: 'Hi', provider, onAgentEvent, streamModelCalls: false });
   * ```
   */
  streamModelCalls?: boolean;
  /** Where a run paused on a tool approval is stored, so it can be resumed later. */
  approvalStore?: ApprovalStore;
  /**
   * TTL: how long a pause for approval (`needsApproval`, an `ask` permission
   * rule, a sign-in) of this run stays decidable, in milliseconds. The saved
   * {@link PendingApproval} gets `expiresAt`; decided after it - also through
   * a durable store in another process or after a restart - the call is
   * denied: the model gets a `kind: 'denied'` tool error whose reason is
   * 'approval expired', audited to `onPermissionDecision`. An `ask` rule's
   * `ttlMs` wins over this default. Unset (or a non-finite value): pauses
   * never expire. `createAgent()` sets this from `approvalTtlMs`.
   */
  approvalTtlMs?: number;
  /**
   * Durable execution: with `checkpointStore`, the run is checkpointed under
   * this id after every model response, as tool results are recorded, and
   * when it pauses, aborts or finishes. Calling `execute()` again with the
   * same id (from any process) picks the session up (LOU-U8):
   *
   * - Unfinished run (crashed or aborted): resumes it. Tool calls of its last
   *   model turn that have no result run first, without calling the model.
   *   New `input` is appended as a user message after those results; input
   *   that re-sends the run's own starting message is treated as a retry
   *   and not appended again (`input: []` also just resumes).
   * - Finished run: continues the conversation - the stored messages are
   *   kept and `input` is appended as the next user turn. Pass only the new
   *   message(s); a re-sent copy of the stored history is not duplicated.
   *   `steps`, `usage` and `toolCalls` count from zero for the new run.
   * - Paused awaiting approval: throws `SessionAwaitingApprovalError`;
   *   resolve it with `resumeAfterApproval()` first.
   *
   * A tool that was running when the process died runs again on resume
   * (at-least-once): make side-effecting tools idempotent - e.g. keyed on
   * the `toolCallId` their `execute` receives - or approval-gated.
   * Delete the session with `checkpointStore.delete(sessionId)`.
   *
   * @example
   * ```ts
   * await AgentExecutor.execute({ agent, input: 'Book a table for 2', provider, sessionId: 'chat-42', checkpointStore });
   * await AgentExecutor.execute({ agent, input: 'Make it 3 people', provider, sessionId: 'chat-42', checkpointStore });
   * ```
   */
  sessionId?: string;
  /**
   * Eve DUI-F5: the id tools, `needsApproval`, permission rules and tool-call
   * hooks see as `ctx.sessionId` when `sessionId` is only where the run is
   * checkpointed - a session turn's `<id>.turn-<n>` gets the session's `<id>`.
   * Default: `sessionId`. Kept in an approval's snapshot for the resumed run.
   */
  contextSessionId?: string;
  /**
   * N10b: who the run acts for (docs/auth.md): handed, frozen, to tools
   * (`ctx.principal`), `needsApproval` policies, permission rules, tool-call
   * hooks and in-process sub-agents, and stored with checkpoints and approval
   * snapshots. Set it only from route auth or a channel's verified sender.
   * An unfinished checkpointed run continues as the principal it was saved
   * with; passing a different one throws `LOUSHO_CONFIG_INVALID`.
   */
  principal?: Principal;
  /**
   * LOU-R16: free-form per-run data (`createAgent`'s `send(x, { metadata })`)
   * handed to every hook invocation as `ctx.metadata` - a correlation id, a
   * tenant, a request tag hooks read but the model never sees. In-process
   * sub-agents inherit it, and it is stored with checkpoints and approval
   * snapshots so a resumed run's hooks keep seeing the run's metadata. An
   * explicit `metadata` on the resuming call wins over the stored one.
   * JSON-serializable: stores may round-trip it through `JSON.stringify`.
   */
  metadata?: Record<string, unknown>;
  /**
   * N9b: where tools' OAuth tokens live (`ctx.getToken()`, docs/oauth.md):
   * `createAgent()` passes its `store.tokens`. A tool that needs sign-in
   * pauses the run (`kind: 'sign-in'`); the pending sign-in is kept here too.
   */
  tokens?: OAuthTokenStore;
  /** Where `sessionId` checkpoints are stored - see `sessionId` for the semantics. */
  checkpointStore?: CheckpointStore;
  /**
   * When true, `input` is treated as a complete, ready-to-send message
   * array that already includes any system prompt it needs (e.g. messages
   * reconstructed from an ExecutionSnapshot by resume.ts). buildMessages()
   * will not prepend a fresh system message built from `agent.prompt` in
   * this case, avoiding a duplicate system message. Only relevant on the
   * "build from scratch" fallback path (no checkpoint loaded); ignored
   * when a checkpoint is rehydrated, since that path never re-injects a
   * system message anyway.
   */
  skipSystemPromptInjection?: boolean;
  /**
   * Starting value for the step counter (and therefore the maxSteps
   * safety-limit budget), used when there is no checkpoint to rehydrate
   * `steps` from but execution is still a continuation of prior work - e.g.
   * resume.ts resuming a run that was paused for approval after already
   * taking some steps. Ignored whenever a checkpoint is loaded, since
   * `checkpoint.stepIndex` is the source of truth in that case. Defaults to
   * 0 (a genuinely fresh run) when omitted.
   */
  initialSteps?: number;
  /**
   * Usage already spent by earlier work this run continues (LOU-V5), used
   * when there is no checkpoint to rehydrate it from - e.g. resume.ts
   * resuming a run paused for approval. Ignored when a checkpoint is loaded.
   */
  initialUsage?: RunUsage;
  /**
   * Tracing/observability hooks (LOU-E1/E2). These are invoked immediately
   * before/after the underlying provider.generate() call and each tool
   * execution inside executeToolCall(). They are plain synchronous or
   * async callbacks - errors thrown from them are NOT swallowed and will
   * propagate out of execute() like any other error, since a hook that
   * silently fails to observe would be worse than one that fails loudly.
   */
  /** Invoked immediately before each provider.generate() call. */
  onLLMRequest?: (request: GenerateOptions) => void | Promise<void>;
  /**
   * Invoked immediately after each provider.generate() call resolves,
   * with the elapsed wall-clock time in milliseconds and what the call
   * spent (LOU-V5: reported usage, or an estimate flagged `estimated`).
   */
  onLLMResponse?: (
    response: GenerateResult,
    latencyMs: number,
    usage: CallUsage
  ) => void | Promise<void>;
  /** Invoked immediately before each tool execution. */
  onToolCall?: (toolCall: ToolCall) => void | Promise<void>;
  /**
   * Invoked immediately after each tool execution settles (success or
   * error), with the elapsed wall-clock time in milliseconds. Fired from a
   * `finally` block so it runs even when the tool throws.
   */
  onToolResult?: (
    toolCall: ToolCall,
    result: {
      toolCallId: string;
      toolName: string;
      result: unknown;
      error?: string;
      requiresApproval?: boolean;
      args?: Record<string, unknown>;
    } | undefined,
    latencyMs: number,
    error?: unknown
  ) => void | Promise<void>;
  /**
   * Trace exporter (LOU-E3/E4/E5). When provided, execute() wraps its run
   * in a 3-level span tree following the OpenTelemetry GenAI conventions
   * (LOU-D9): an `invoke_agent {name}` span, with a nested `chat {model}`
   * span around each provider.generate() call and a nested
   * `execute_tool {tool}` span around each tool execution, both parented to
   * the agent span via Span.parentId. Omitted (or no exporter) means
   * withSpan() is a no-op wrapper - execute()'s behavior is unchanged.
   */
  exporter?: TraceExporter;
  /**
   * When true (the default), the DEPRECATED span attributes omit potentially
   * sensitive content (the `invoke_agent` span leaves out `input`, `chat`
   * leaves out `prompt` and `execute_tool` leaves out `args`/`result`). Set
   * it to false to record them. Token counts, finish reason, tool name and
   * error/latency are never redacted. Permission-decision events still carry
   * the call's args unless this is explicitly true. The `gen_ai.*` content attributes are governed by
   * `captureContent` instead.
   */
  redactContent?: boolean;
  /**
   * Record message and tool-argument content on the OpenTelemetry GenAI
   * attributes (`gen_ai.input.messages`, `gen_ai.output.messages`,
   * `gen_ai.system_instructions`, `gen_ai.tool.call.arguments`,
   * `gen_ai.tool.call.result`). Off by default; falls back to the
   * `OTEL_INSTRUMENTATION_GENAI_CAPTURE_MESSAGE_CONTENT` environment
   * variable when omitted.
   */
  captureContent?: boolean;
  /**
   * SandboxAdapter used for tools flagged `requiresSandbox` (LOU-F5). Since
   * AgentExecutor is a static, instance-free API, this is read per-call
   * (`options.sandbox ?? NoopSandbox`) rather than held as construction
   * state. Defaults to NoopSandbox - the zero-isolation, trusted-host
   * adapter - when omitted, so existing callers see no behavior change.
   */
  sandbox?: SandboxAdapter;
  /**
   * Registered `AgentHook`s (LOU-Q1) to run at each pre/post tool-call and
   * pre/post generate point in the execution loop. Purely additive: when
   * omitted (the default), no hooks run and behavior is byte-for-byte
   * identical to before hooks existed. Hooks run in registration order
   * (see HookRegistry); a hook that throws aborts the current step and
   * propagates out of execute() as a rejected promise, exactly like an
   * unrecovered tool/provider error - it is never silently swallowed.
   *
   * This same option is honored by `resumeAfterApproval()` (resume.ts) for
   * its deferred, post-approval tool execution, so a hook registered here
   * fires consistently regardless of which of the two tool-execution call
   * sites handles a given tool call.
   */
  hooks?: HookRegistry;
  /**
   * LOU-T1: opaque, consumer-owned business/domain state (an order id, a
   * ticket id, a workflow stage, ...) written into every checkpoint record
   * alongside execution state, for the lifetime of this execute() call.
   * See `Checkpoint.businessState` (src/execution/checkpoint.ts) for the
   * full contract - the SDK never reads or interprets this value, it is
   * simply copied verbatim into each checkpoint write below. Purely
   * additive: omitted (the default), the checkpoint record's
   * `businessState` field is simply absent, and behavior is identical to
   * before this option existed.
   */
  businessState?: unknown;
  /**
   * LOU-T4: opt-in to Factor-9-style compaction of a `provider.generate()`
   * failure INTO the conversation (as a small `{error, category, ...}`
   * message the model itself sees on its next turn) for categories where
   * that's actually useful - 'rate-limit', 'timeout' and
   * 'context-length-exceeded' (see `isModelActionableProviderErrorCategory()`
   * in errors.ts). Defaults to `false`.
   *
   * Regardless of this flag, EVERY provider.generate() failure is always
   * compacted via `compactProviderError()` before it reaches a caller - the
   * flag only controls WHERE the compacted form goes:
   *
   * - `false` (default, and the only behavior for 'auth-failure'/'unknown'
   *   regardless of this flag): `execute()` rejects with a
   *   `CompactedLLMProviderError` (small message, no raw response
   *   body/stack, original error on `.cause`). This is a strict, ADDITIVE
   *   improvement over the pre-LOU-T4 behavior of rejecting with whatever
   *   raw error the specific provider adapter happened to throw - an
   *   existing `catch` block keeps working (still a rejected promise, still
   *   `instanceof LLMProviderError`, still has `.message`), it just sees a
   *   smaller/friendlier error object. No opt-in needed for this part: it's
   *   a pure correctness/ergonomics fix in the same spirit as this
   *   codebase's other Strong-scored factors, not a control-flow change.
   * - `true`: for the three model-actionable categories above, the
   *   compacted error is instead pushed onto `messages` (tagged so it's
   *   distinguishable from real user input - see the `[provider-error]`
   *   prefix in providerErrorMessage()) and the loop retries generation, consuming
   *   one `maxSteps` step exactly like any other turn. THIS part is
   *   opt-in-only because it is a genuine behavior change for those three
   *   categories: today they always reject; with this flag set, a
   *   persistently-failing provider call instead keeps consuming steps
   *   until either it succeeds, a non-actionable failure occurs, or
   *   `maxSteps` is exhausted (at which point `execute()` still rejects
   *   with the last compacted error - see finishRun() - rather than
   *   silently returning a hollow "successful" result).
   */
  surfaceRetryableProviderErrors?: boolean;
  /**
   * LOU-V1: cancels the run. The signal is checked before every model call
   * and every tool call, and is forwarded to the provider (as
   * `GenerateOptions.signal`) and to each tool's
   * `execute(args, { abortSignal })` so in-flight work can stop early.
   * Delegated child agents inherit it.
   *
   * An aborted run does NOT reject: it resolves with
   * `finishReason: 'aborted'` and the transcript/steps so far, after
   * emitting an `abort` event and then a `finish` event. A rejection caused
   * by the abort (e.g. an `AbortError` from the provider) counts as the
   * abort, never as a failure. With `sessionId` + `checkpointStore` the
   * state is checkpointed, so calling `execute()` again with the same
   * `sessionId` resumes where the run stopped. An already-aborted signal
   * returns at once without calling the provider.
   *
   * @example
   * ```ts
   * const result = await AgentExecutor.execute({
   *   agent, input: 'Summarize the report', provider,
   *   signal: AbortSignal.timeout(30_000), // or controller.signal
   * });
   * if (result.finishReason === 'aborted') console.log('cancelled');
   * ```
   */
  signal?: AbortSignal;
  /**
   * LOU-V9: input pushed while the run goes on (`inputQueue.push()`), so
   * a non-streaming caller can add to it like `run.enqueue()` does. Each
   * input joins the transcript at the next safe point - after the current
   * step's tool results, before the next model call - and a run whose model
   * just gave its final reply takes another step for it. With checkpointing,
   * an input still waiting rides at the end of every checkpoint, so a crash
   * does not lose it. One queue serves one run. See docs/queue-and-steer.md.
   */
  inputQueue?: InputQueue;
  /**
   * LOU-V3: how many tool calls from ONE model turn may run at the same
   * time. Defaults to `'unbounded'` (every call of the turn runs
   * concurrently); `1` restores strictly sequential execution. Must be a
   * positive integer or `'unbounded'`.
   *
   * Guarantees, whatever the limit:
   * - Tool-result messages are appended to the transcript in the model's
   *   call order, never completion order, so the next provider request is
   *   deterministic.
   * - Calls are started in call order. Each call's `tool-call` event,
   *   `onToolCall`, argument validation, `preToolCall` hooks and
   *   `needsApproval` check run before it starts, one call at a time; its
   *   `tool-result` event fires as soon as it completes (completion order).
   *   With `1`, events alternate call/result exactly as before.
   * - Approval: the first call that needs approval stops the batch. Calls
   *   before it run (concurrently) and are recorded; the run then pauses
   *   on that call (`finishReason: 'awaiting-approval'`); calls after it
   *   never start in this run. `resumeAfterApproval()` records the paused
   *   call's result and then runs the calls after it the same way (LOU-U7).
   * - A failing tool does not affect its siblings - each gets its own error
   *   result. A propagating error (`PropagatingToolError`, a throwing hook)
   *   stops new calls from starting, waits for the running ones, then
   *   rejects `execute()` - no tool is left running detached.
   * - An abort (`signal`) mid-batch resolves with `finishReason: 'aborted'`:
   *   finished calls keep their results, the rest get a "cancelled" result.
   * - With checkpointing, the model's turn is checkpointed before any call
   *   starts, and each result is checkpointed by its toolCallId as soon as
   *   its call settles, so a resumed run never re-runs a finished call -
   *   even one that completed behind a slower earlier call.
   *
   * @example
   * ```ts
   * await AgentExecutor.execute({ agent, input: 'Compare 3 cities', provider, toolConcurrency: 2 });
   * ```
   */
  toolConcurrency?: ToolConcurrency;
  /**
   * Eve TOOLS-F8: the most characters of one tool result the model gets (its
   * JSON, as the `tool` message content). A longer result keeps its head and
   * tail with a marker saying how much was cut. Default 50_000 (about 12k
   * tokens); `Infinity` turns the cap off. `onToolResult`, hooks and
   * `tool.done` events still get the whole result.
   */
  maxToolResultChars?: number;
  /**
   * LOU-V4: a zod schema the final reply must match, as JSON (tools can
   * still be called first). It is validated into `result.object`; an invalid
   * reply gets one repair step (counted against `maxSteps`), then the run
   * ends with `finishReason: 'output-invalid'` and `outputError`. See
   * docs/structured-output.md. As `{ schema, promptSchema: false }`, the
   * schema is sent only on `responseFormat`, not in the system prompt too
   * (audit invoice F12).
   *
   * @example
   * ```ts
   * const { object } = await AgentExecutor.execute({ agent, input: 'Weather in Paris?', provider, output: z.object({ tempC: z.number() }) });
   * ```
   */
  output?: StandardSchemaV1 | OutputSpec;
  /**
   * LOU-Y4.2: called exactly once when this run ends, however it ends: with
   * `{ result }` when it resolves (any `finishReason`, including `'aborted'`,
   * `'awaiting-approval'` and `'max-steps'`) or `{ error }` when it rejects.
   * The run settles after it returns; an error it throws rejects the run.
   */
  onRunEnd?: (end: { result?: ExecutionResult; error?: unknown }) => void | Promise<void>;
  /**
   * LOU-W9.2: what to do when a checkpointed run is resumed (`sessionId`
   * + `checkpointStore`, an unfinished run) or paused run is continued
   * (`resumeAfterApproval()`) by an agent that differs from the one that saved
   * it: a different model, tools with other names or input schemas, other
   * instructions. `'warn'` (default) reports an `agent.drift` event and a
   * `console.warn`, then continues; `'error'` rejects with
   * `LOUSHO_AGENT_DRIFT` before any model call or tool runs, leaving the
   * checkpoint untouched; `'ignore'` does nothing. A pending tool call whose
   * tool no longer exists always rejects with `LOUSHO_RESUME_TOOL_MISSING`.
   * Checkpoints and snapshots saved before this option existed are not checked.
   * See docs/durable-execution.md#resuming-with-a-changed-agent.
   */
  onAgentDrift?: AgentDriftMode;
  /**
   * LOU-V13: how much the model reasons, sent on every model call of the run
   * (`GenerateOptions.reasoning`). See docs/reasoning.md.
   */
  reasoning?: ReasoningOption;
  /**
   * Eve PROV-F4: Anthropic prompt caching on every model call of the run
   * (`GenerateOptions.promptCaching`); `'auto'` when unset. See docs/models-and-cost.md#prompt-caching.
   */
  promptCaching?: PromptCachingOption;
  /**
   * N6: agents this run can hand the conversation to, one tool each. A call
   * to one is not run as a tool: once the other calls of its step are done,
   * the run goes on with the target's configuration (`ResolvedHandoff.spec()`)
   * on the transcript its `inputFilter` returns. `createAgent({ handoffs })`
   * sets this; see docs/handoffs.md.
   */
  handoffs?: readonly ResolvedHandoff[];
  /** N6: how many handoffs one run may make (default 5); a handoff call over it gets a tool error. */
  maxHandoffs?: number;
  /**
   * N2: tunes tool search. Tools marked `deferLoading` (by `defineTool()` or
   * an MCP server) are withheld from the model, which finds them with the
   * built-in `tool_search` tool, once their definitions reach
   * `thresholdPercent` (default 10%) of the context window. `false` sends
   * every tool on every call. See docs/tool-search.md.
   *
   * @example
   * ```ts
   * await AgentExecutor.execute({ agent, input: 'What is 100 USD in EUR?', provider, toolRegistry, toolSearch: { thresholdPercent: 0 } });
   * ```
   */
  toolSearch?: false | ToolSearchOptions;
}

/**
 * Execution result. `TObject` is the type of `object` - `z.output` of the
 * `output` schema for `createAgent({ output })` agents.
 */
export interface ExecutionResult<TObject = unknown> {
  text: string;
  /** LOU-V13: the model's reasoning text over the run's steps, when it reported any (never part of `text` or `messages` content). */
  reasoning?: string;
  messages: Message[];
  toolCalls: ToolCall[];
  /**
   * Tokens, cost and per-model breakdown of the whole run, including
   * delegated children and steps before a resume (LOU-V5). See `formatUsage()`.
   */
  usage: RunUsage;
  /** One entry per model call of this process's run, in order (LOU-V5). */
  stepUsage?: StepUsage[];
  finishReason: ExecutionFinishReason;
  /**
   * Eve CORE-F15: why a run that ended `'aborted'` was aborted - the
   * signal's `reason` as `{ name, message }`: `'TimeoutError'` for
   * `AbortSignal.timeout()`, `'AbortError'` for a plain
   * `controller.abort()`, an Error reason's own name and message, or
   * `'AbortError'` with the text of a non-Error reason
   * (`controller.abort('user left')`). Absent on other endings.
   *
   * @example
   * ```ts
   * const result = await agent.send('hi', { signal: AbortSignal.timeout(30_000) });
   * if (result.abortReason?.name === 'TimeoutError') console.log('timed out');
   * ```
   */
  abortReason?: {
    /** The abort reason's error name (`'AbortError'`, `'TimeoutError'`, or a custom error's). */
    name: string;
    /** The abort reason's message. */
    message: string;
  };
  steps: number;
  /** With `finishReason: 'awaiting-approval'`, the pending approval to decide (the first of `approvalIds`). */
  approvalId?: string;
  /**
   * Eve TOOLS-F12: with `finishReason: 'awaiting-approval'`, every approval
   * the paused step waits on, in call order (`approvalId` is the first). When
   * one model step has several calls that need approval, the run pauses once
   * on all of them: decide each (`agent.approvals.resolve()`, in any order,
   * or `resolveAll()`), and the step's approved calls run once the last one
   * is decided.
   */
  approvalIds?: string[];
  /** LOU-V4: the final reply parsed and validated with `output`; absent unless it was valid. */
  object?: TObject;
  /** LOU-V4: why the final reply did not match `output` (`finishReason: 'output-invalid'`). */
  outputError?: OutputError;
  /**
   * Audit invoice F6: `true` when `object` came from the repair step - the
   * first reply did not validate, and the model answered again. The repair
   * may change values to satisfy the schema (a refinement such as
   * `total = subtotal + tax` can make it rewrite a total), so check business
   * rules on `object` yourself. Absent when the first reply validated.
   */
  outputRepaired?: true;
  /** LOU-Y4.2: the run's background sub-agents and their final statuses; absent when it started none. */
  backgroundTasks?: BackgroundTaskView[];
  /** LOU-V6: the limit that ended the run (`finishReason: 'budget-exceeded'`). */
  budget?: BudgetExceeded;
  /** LOU-X4: the guardrail that ended the run (`finishReason: 'guardrail'`). */
  guardrail?: GuardrailTrip;
  /** N6: the agent that produced the final reply: the run's own, or the one it handed off to (docs/handoffs.md). */
  agentName?: string;
}

/**
 * Applies `skills` and `subagents`: their prompt blocks and their tools.
 * Module-level (exported) so resume.ts runs the same extension for the
 * target of an approved handoff (N6) as execute() does for a fresh run.
 */
export async function extendRunOptions(options: ExecuteOptions): Promise<ExecuteOptions> {
  const skilled = withSkills(options.agent, options.toolRegistry, options.skills);
  const subagented = await withSubagents(skilled.agent, skilled.toolRegistry, options.subagents, options);
  // N2: the deferral is the active agent's own; set on every call, so a handoff target never keeps the lead's.
  const { deferral, ...searched } = withToolSearch(options, subagented.agent, subagented.toolRegistry);
  // N14: `run_code` sees the run's tools as they are now (deferred ones are not callable by default).
  const coded = await withCodeMode(options, searched.agent, searched.toolRegistry, deferral);
  const extended = { ...subagented, ...coded };
  // N4: a run that starts in plan mode is told so. LOU-V4: the output instruction goes last in the system prompt.
  const { agent } = extended;
  const blocks = [...(permissionModeOf(options) === 'plan' ? [PLAN_MODE_INSTRUCTION] : []), ...(options.output ? [outputInstruction(options.output)] : [])];
  if (blocks.length === 0) return withDeferral({ ...options, ...extended }, deferral);
  const instruction = blocks.join('\n\n');
  const prompt = agent.prompt ? `${agent.prompt}\n\n${instruction}` : instruction;
  return withDeferral({ ...options, ...extended, agent: extendAgent(agent, { prompt }) }, deferral);
}

/**
 * Agent Executor
 */
export class AgentExecutor {
  /**
   * Runs the agent to its result. With a listener (`onAgentEvent`), its
   * model calls are streamed to it (M9; see
   * {@link ExecuteOptions.streamModelCalls}).
   */
  static async execute(options: ExecuteOptions): Promise<ExecutionResult> {
    // AgentExecutor is a static, instance-free API - there is no
    // constructor to guard these, so execute() is the first and only
    // entry point where a missing required option can be caught before it
    // fails deep inside runAgentLoop() with a generic "Cannot read
    // properties of undefined" error (e.g. `provider.generate(...)`
    // throwing because `provider` was never checked).
    this.validateExecuteOptions(options);

    // LOU-D41: the run reports to its listeners through its event sink.
    return observeRun(options, (observed) => {
      // The entire run is wrapped in a top-level 'agent.run' span (LOU-E5),
      // whose `id` is threaded as `parentId` into the nested 'llm.generate'
      // and 'tool.call' spans, giving the 3-level span tree its parent/child
      // relationships without any instance state.
      if (observed.agentSpanId) return this.runWithEnd(observed, observed.agentSpanId);
      const init = agentRunSpanInit(observed, {
        redactContent: observed.redactContent,
        captureContent: resolveCaptureContent(observed.captureContent),
      });
      return withSpan(
        observed.exporter,
        init.name,
        init.attributes,
        async (agentSpan) => this.runWithEnd(observed, agentSpan.id),
        observed.parentSpanId,
        init.kind
      );
    });
  }

  /** runAgentLoop() with `skills`/`subagents` applied, then `onRunEnd` once, however the run ends (LOU-Y4.2). */
  private static async runWithEnd(options: ExecuteOptions, agentSpanId: string): Promise<ExecutionResult> {
    let run = options;
    let end: { result?: ExecutionResult; error?: unknown } = {};
    // LOU-V6: a `maxDurationMs` budget aborts the run's signal.
    const budget = startBudget(options.limits, options.sessionBudget, options.signal);
    try {
      run = await extendRunOptions(budget ? { ...options, signal: budget.signal } : options);
      const result = await this.runAgentLoop(run, agentSpanId, budget);
      end = { result };
      return result;
    } catch (error) {
      end = { error };
      throw error;
    } finally {
      budget?.dispose();
      options.inputQueue?.close();
      await run.onRunEnd?.(end);
    }
  }

  /**
   * Runs the agent like {@link AgentExecutor.execute} - same options, same
   * loop, same `ExecutionResult` - and streams the run as typed
   * `AgentEvent`s (LOU-V2). Model output is streamed through
   * `provider.stream()` when the provider has it (one `text.delta` per
   * chunk); otherwise each step uses `generate()` and emits its text as a
   * single `text.delta`. `onAgentEvent` gets the same events; the other callbacks still fire.
   *
   * The run starts immediately. Iterate the returned {@link AgentRun} for
   * the events, or await `run.result`; breaking out of the `for await`
   * early aborts the run (`result` then resolves with
   * `finishReason: 'aborted'`). Invalid options throw synchronously.
   * See docs/stream-events.md for the event schema.
   *
   * @example
   * ```ts
   * const run = AgentExecutor.stream({ agent, input: 'Weather in Paris?', provider, toolRegistry });
   * for await (const event of run) {
   *   if (event.type === 'text.delta') process.stdout.write(event.text);
   * }
   * const { finishReason } = await run.result;
   * ```
   */
  static stream(options: ExecuteOptions): AgentRun {
    this.validateExecuteOptions(options, 'AgentExecutor.stream');
    return startAgentRun(({ signal, sink, inputQueue }) => {
      const streaming: StreamingExecuteOptions = { ...options, signal, inputQueue, [RUN_EVENTS]: sink };
      return this.execute(streaming);
    }, options.signal, options.inputQueue);
  }

  /**
   * Forks a checkpointed run at an earlier step (LOU-D44): takes the newest
   * entry of `fromStep` in the session's checkpoint history, applies `patch`
   * (rewrite messages, replace a tool result, change `businessState`, queue
   * a user message) and saves it as the `'in-progress'` checkpoint of a new
   * session. The original session is not changed. Throws
   * `LOUSHO_CHECKPOINT_NOT_FOUND` when the history has no such step. See
   * docs/durable-execution.md#fork-and-replay.
   *
   * @example
   * ```ts
   * const fork = await AgentExecutor.fork({ sessionId: 'job-1', fromStep: 1, checkpointStore, patch: { appendInput: 'Use Celsius.' } });
   * await AgentExecutor.execute({ agent, provider, input: [], sessionId: fork.sessionId, checkpointStore });
   * ```
   */
  static fork(options: ForkOptions): Promise<ForkResult> {
    return forkSession(options);
  }

  /**
   * The actual execution loop, split out of execute() so the top-level
   * 'agent.run' span (LOU-E5) can wrap it via withSpan() while still
   * exposing execute() as the same static, instance-free entry point.
   */
  private static async runAgentLoop(
    options: ExecuteOptions,
    agentSpanId: string,
    budget?: RunBudget
  ): Promise<ExecutionResult> {
    const { agent } = options;
    runEventsOf(options)?.runStart(agent);

    // Build tools (N6: and one per handoff)
    const tools = runTools(options);
    // N1a: the provider must be able to send every hosted tool.
    assertHostedToolsSupported(options.hostedTools, agent, options.provider);

    // A checkpointed run holds its id's run lease while it runs, so another process cannot resume it meanwhile.
    const held = (options as RunLeaseOptions)[HELD_RUN_LEASE];
    const lease = held ?? (options.sessionId && options.checkpointStore ? await acquireRunLease(options.checkpointStore, options.sessionId) : undefined);
    try {
      const state = await loadRunState(options);
      state.lease = lease;
      try {
        return await this.runLoadedAgentLoop(options, state, tools, agentSpanId, budget);
      } catch (error) {
        // Eve MA-F1: a lead that ran this as a sub-agent still counts what it spent before failing.
        attachRunUsage(error, state.usage);
        throw error;
      }
    } finally {
      if (!held) await lease?.release();
    }
  }

  /** runAgentLoop() once the run's state is loaded. */
  private static async runLoadedAgentLoop(
    options: ExecuteOptions,
    state: AgentRunState,
    tools: ToolDefinition[],
    agentSpanId: string,
    budget?: RunBudget
  ): Promise<ExecutionResult> {
    // N10b: the run's principal, as loaded (an unfinished checkpoint's wins), frozen once. `options` is
    // this run's own copy (extendRunOptions() made it), and the scope every tool call hands on.
    options.principal = state.principal;
    // LOU-R16: likewise the run's metadata (an unfinished checkpoint's fills in when this call set none).
    options.metadata = state.metadata;
    await checkResumedAgent(options, state, tools);
    state.budget = budget;
    // LOU-X4: the new input is checked before anything else runs.
    const blocked = await checkInputGuardrails(options, [state.messages, state.queuedInput]);
    if (blocked) return this.stopForGuardrail(options, state, blocked);
    // N5b: the `runInParallel` ones check the (possibly rewritten) input while the first model call runs.
    state.inputCheck = startParallelInputGuardrails(options, [...state.messages, ...state.queuedInput]);

    options.inputQueue?.listen((queued) => {
      runEventsOf(options)?.inputQueued(queued);
      // LOU-V9: checkpointed at once, so a crash before it is applied does not lose it.
      saveStepCheckpoint(options, state).catch(() => undefined);
    });

    // LOU-U7/U9: a resumed transcript may end with a model turn whose tool
    // calls (some of them) have no result yet - finish those first, without
    // calling the model again.
    if (state.pendingToolCalls.length > 0) {
      // N5b: no tool runs before the parallel input guardrails passed.
      const blockedLate = await this.settleInputCheck(options, state);
      if (blockedLate) return blockedLate;
      const resumed = await this.runStepOrAbort(options, state, () =>
        this.runPendingToolCalls(options, state, agentSpanId)
      );
      if (resumed !== 'continue') {
        return resumed;
      }
      // N6: the resumed step handed off.
      if (state.switched) return this.runSwitched(state, agentSpanId);
    }

    return this.runSteps(options, state, tools, agentSpanId);
  }

  /** The generate -> tools loop of runAgentLoop(), run once `state` is loaded. */
  private static async runSteps(
    options: ExecuteOptions,
    state: AgentRunState,
    tools: ToolDefinition[],
    agentSpanId: string
  ): Promise<ExecutionResult> {
    // N6: counted across the agents of the run (a handoff keeps the run's maxSteps).
    const maxSteps = maxStepsOf(options);
    let repaired = false;

    // Execution loop with tool calling. LOU-V1: the signal is checked
    // before every model call (here) and every tool call (runToolCalls()).
    while (state.steps < maxSteps) {
      const stopped = this.stopBeforeStep(options, state, agentSpanId, tools);
      if (stopped) {
        return stopped;
      }
      state.steps++;
      this.applyQueuedInput(options, state);

      const outcome = await this.runStepOrAbort(options, state, () =>
        this.runStep(options, state, tools, agentSpanId)
      );
      // N6: the step handed off; the run goes on as the target.
      if (state.switched) return this.runSwitched(state, agentSpanId);
      if (await this.stepsOnForInput(options, state, outcome, maxSteps)) {
        continue;
      }
      if (outcome === 'stop') {
        const output = await this.checkOutput(options, state, !repaired && state.steps < maxSteps, state.finishReason === 'length');
        if (output === 'repair') {
          repaired = true;
          continue;
        }
        // Audit invoice F6: the object came from the repair step, which may have changed values to make it validate.
        return this.finishRun(options, state, repaired && output && 'object' in output ? { ...output, outputRepaired: true } : output);
      }
      if (typeof outcome !== 'string') {
        return outcome;
      }
    }

    return this.outOfSteps(options, state, agentSpanId, tools);
  }

  /** The run's end once the loop left without a result: aborted, or out of steps. */
  private static async outOfSteps(options: ExecuteOptions, state: AgentRunState, agentSpanId: string, tools: ToolDefinition[]): Promise<ExecutionResult> {
    if (options.signal?.aborted) {
      return this.abortRun(options, state);
    }
    // Audit log-incident F21: with `output` set, one last tool-less call
    // lets the model answer from what it gathered instead of returning
    // nothing.
    if (options.output) {
      const output = await this.forcedAnswer(options, state, agentSpanId, tools);
      if (output && 'finishReason' in output) return output;
      if (state.finishReason !== 'output-invalid') state.finishReason = 'max-steps';
      return this.finishRun(options, state, output);
    }
    // LOU-U19: every non-final turn 'continue's, so leaving the loop here
    // means the step budget (counting `initialSteps` of a resumed run) is
    // spent while the model still wanted to go on.
    state.finishReason = 'max-steps';
    return this.finishRun(options, state);
  }

  /**
   * The salvage call when `maxSteps` ran out with an `output` schema still
   * unanswered (audit log-incident F21): one more model call, no tools
   * offered (a transcript with tool calls sends the run's tools with
   * `toolChoice: 'none'`), asking the model to answer from what it gathered. Its reply is
   * validated like a normal final reply - a valid object ends the run
   * 'max-steps' with `object` set, an invalid one 'output-invalid' (no
   * repair: the step budget is spent). Returns the call's own terminal
   * result when it ended the run early (blocked input, aborted mid-call),
   * or `undefined` when no call could be made - another budget cap already
   * spent, or a steered/failed generation - and the run ends 'max-steps'
   * as before.
   */
  private static async forcedAnswer(
    options: ExecuteOptions,
    state: AgentRunState,
    agentSpanId: string,
    tools: ToolDefinition[]
  ): Promise<ExecutionResult | { object: unknown } | { outputError: OutputError } | undefined> {
    if (state.budget?.check(state.usage, state.steps, true)) return undefined;
    const prompt: Message = {
      role: 'user',
      content: 'You are out of steps. Answer now with the final JSON result only - no tools, no commentary.',
    };
    state.messages.push(prompt);
    markRequestOnly(state, prompt);
    // A transcript with tool calls needs the tool definitions (Anthropic rejects tool blocks without them), so they go along with `toolChoice: 'none'`.
    const sendTools = tools.length > 0 && state.messages.some((message) => message.role === 'tool');
    const forced: ExecuteOptions = sendTools
      ? { ...options, hostedTools: undefined, modelSettings: { ...options.modelSettings, toolChoice: 'none' } }
      : { ...options, hostedTools: undefined };
    const generatedStep = await this.generateOrSurfaceError(forced, state, sendTools ? tools : [], agentSpanId);
    if (!generatedStep || generatedStep === 'steered') return undefined;
    if (!('generated' in generatedStep)) return generatedStep;
    const { generated, measured } = generatedStep;
    const stepUsage = recordStep(state, measured);
    noteReasoning(state, generated.reasoning);
    const text = await this.guardOutput(options, state, generated);
    if (typeof text !== 'string') return text;
    if (text) {
      state.finalText = text;
      runEventsOf(options)?.textDone(text, stepUsage);
      state.messages.push(withHostedCalls({ role: 'assistant', content: text }, generated.hostedToolCalls));
    }
    const checked = await this.checkOutput(options, state, false, generated.finishReason === 'length');
    return checked === 'repair' ? undefined : checked;
  }

  /** N6: the rest of the run, as the agent the last step handed off to. */
  private static runSwitched(state: AgentRunState, agentSpanId: string): Promise<ExecutionResult> {
    const { options, tools } = state.switched as NonNullable<AgentRunState['switched']>;
    state.switched = undefined;
    return this.runSteps(options, state, tools, agentSpanId);
  }

  /**
   * Whether the loop takes another step for waiting input: after a step a
   * steer aborted (LOU-V10), or after a final reply with input queued during
   * it (LOU-V9). It does once the checkpoint holding that input is written.
   */
  private static async stepsOnForInput(
    options: ExecuteOptions,
    state: AgentRunState,
    outcome: string | ExecutionResult,
    maxSteps: number
  ): Promise<boolean> {
    const queued = outcome === 'stop' && Boolean(options.inputQueue?.messages.length) && state.steps < maxSteps;
    if (outcome !== 'steered' && !queued) return false;
    await state.saving;
    return true;
  }

  /** LOU-V9: appends the queued input to the transcript, for the model call of step `state.steps`. */
  private static applyQueuedInput(options: ExecuteOptions, state: AgentRunState): void {
    for (const queued of options.inputQueue?.take() ?? []) {
      state.messages.push(...queued.messages);
      runEventsOf(options)?.inputApplied(queued.id, state.steps);
    }
  }

  /** The run's end when it must stop before the next model call: aborted (LOU-V1) or over budget (LOU-V6). */
  private static stopBeforeStep(options: ExecuteOptions, state: AgentRunState, agentSpanId: string, tools: ToolDefinition[]): Promise<ExecutionResult> | undefined {
    if (options.signal?.aborted) return this.abortRun(options, state);
    const exceeded = state.budget?.check(state.usage, state.steps);
    if (exceeded?.limit === 'maxSteps' && options.output && state.budget?.mode(exceeded) !== 'throw') {
      return this.stepLimitAnswer(options, state, exceeded, agentSpanId, tools);
    }
    return exceeded && this.stopForBudget(options, state, exceeded);
  }

  /**
   * Eve CORE-F5: a `limits.maxSteps` that runs out with an `output` schema
   * still unanswered gets the same forced answer as `maxSteps`
   * ({@link forcedAnswer}). The run still ends 'budget-exceeded' with
   * `result.budget` - with `object` when the answer validated, or
   * 'output-invalid' with `outputError` when it did not.
   */
  private static async stepLimitAnswer(
    options: ExecuteOptions,
    state: AgentRunState,
    budget: BudgetExceeded,
    agentSpanId: string,
    tools: ToolDefinition[]
  ): Promise<ExecutionResult> {
    runEventsOf(options)?.budgetExceeded(budget);
    const output = await this.forcedAnswer(options, state, agentSpanId, tools);
    if (output && 'finishReason' in output) return output;
    if (state.finishReason !== 'output-invalid') state.finishReason = 'budget-exceeded';
    return { ...(await this.finishRun(options, state, output)), budget };
  }

  /**
   * LOU-V4: with `output`, parses and validates the final reply. When it is
   * invalid and `canRepair`, queues the issues for one more step ('repair');
   * otherwise ends the run as 'output-invalid'. A reply cut off at the
   * `maxTokens` limit (`truncated`) gets no repair - it would be cut off the
   * same way - and reports `outputError.kind: 'truncated'` (Eve CORE-F12).
   */
  private static async checkOutput(
    options: ExecuteOptions,
    state: AgentRunState,
    canRepair: boolean,
    truncated: boolean
  ): Promise<'repair' | { object: unknown } | { outputError: OutputError } | undefined> {
    if (!options.output) return undefined;
    const checked = await validateOutput(options.output, state.finalText);
    if ('object' in checked) return checked;
    if (truncated) {
      state.finishReason = 'output-invalid';
      return { outputError: truncatedOutput(checked) };
    }
    if (canRepair) {
      // Eve CORE-F3: the rejected reply and the repair prompt go to the next model call only.
      const rejected = state.messages.at(-1);
      const prompt = outputRepairMessage(options.output, checked);
      state.messages.push(prompt);
      markRequestOnly(state, prompt);
      if (rejected?.role === 'assistant' && !rejected.toolCalls?.length && state.finalText && rejected.content === state.finalText) {
        markRequestOnly(state, rejected);
      }
      return 'repair';
    }
    state.finishReason = 'output-invalid';
    return { outputError: checked.outputError };
  }

  /**
   * Runs one step (runStep(), or the resumed pending tool calls of the
   * current step - LOU-U7/U9), bracketed by the stream's step events, with
   * a thrown error emitted as an `error` event and rethrown - unless the
   * run's signal was aborted, in which case the rejection is the abort
   * itself (e.g. the provider's AbortError) and the run ends as 'aborted'
   * instead (LOU-V1).
   */
  private static async runStepOrAbort<T extends string>(
    options: ExecuteOptions,
    state: AgentRunState,
    step: () => Promise<T | ExecutionResult>
  ): Promise<T | ExecutionResult> {
    const runEvents = runEventsOf(options);
    runEvents?.stepStart(state.steps);
    try {
      const outcome = await step();
      const finishReason = typeof outcome === 'string' ? undefined : outcome.finishReason;
      runEvents?.stepDone(state.steps, outcome === 'steered' ? 'steered' : finishReason);
      return outcome;
    } catch (error) {
      if (options.signal?.aborted) {
        runEvents?.stepDone(state.steps, 'aborted');
        return this.abortRun(options, state);
      }
      runEvents?.error(error);
      runEvents?.stepDone(state.steps, 'error');
      throw error;
    }
  }

  /**
   * One generate -> (tool calls) turn of the loop. Resolves to 'continue'
   * to take another step, 'stop' once the model replied without tool
   * calls, or the ExecutionResult to return early when a tool call paused
   * the run for approval.
   */
  private static async runStep(
    options: ExecuteOptions,
    state: AgentRunState,
    tools: ToolDefinition[],
    agentSpanId: string
  ): Promise<'continue' | 'stop' | 'steered' | ExecutionResult> {
    const generatedStep = await this.generateOrSurfaceError(options, state, tools, agentSpanId);
    if (!generatedStep || generatedStep === 'steered') {
      return generatedStep ?? 'continue';
    }
    if (!('generated' in generatedStep)) return generatedStep;
    const { generated, measured } = generatedStep;

    // A turn produced a real result - any pending "the last thing that
    // happened was a provider failure" tracking no longer applies.
    state.lastSurfacedProviderError = undefined;

    // Update usage (LOU-V5)
    const stepUsage = recordStep(state, measured);
    // N1a: the provider already ran its hosted calls; they are counted, never run here.
    countHostedCalls(state.usage, generated.hostedToolCalls);

    const text = await this.guardOutput(options, state, generated);
    if (typeof text !== 'string') return text;
    // F13: `functions.read_file` runs `read_file` when that is a known tool.
    const known = new Set([...tools.map((tool) => tool.function.name), ...(options.toolRegistry?.list() ?? [])]);
    const toolCalls = resolveToolCallNames(generated.toolCalls, known);
    // A reply that ends 'tool_calls' without any call (no tool runs) ended like any final reply.
    const reason = modelFinishReason(generated.finishReason);
    const finishReason = reason === 'tool_calls' && !toolCalls?.length ? 'stop' : reason;
    const result = { ...generated, text, toolCalls, finishReason };
    noteReasoning(state, result.reasoning);

    // Handle text response
    if (result.text) {
      state.finalText = result.text;
      runEventsOf(options)?.textDone(result.text, stepUsage);
    }

    // Handle tool calls
    if (result.toolCalls && result.toolCalls.length > 0) {
      // LOU-V6: a budget spent by this call stops the run before its tools run.
      const exceeded = state.budget?.check(state.usage, state.steps, true);
      if (exceeded) {
        state.toolCalls.push(...result.toolCalls);
        state.messages.push(assistantTurn(result));
        pushAbortedBatchResults(state, result.toolCalls.map((toolCall) => ({ toolCall })), 'the run reached a budget limit', options.maxToolResultChars);
        return this.stopForBudget(options, state, exceeded);
      }
      const paused = await this.runToolCalls(options, state, assistantTurn(result), result.toolCalls, agentSpanId);
      if (paused) {
        return paused;
      }

      // Continue loop for next generation
      state.finishReason = result.finishReason;
      return 'continue';
    }

    // No tool calls, we're done. Push the assistant's final reply onto
    // currentMessages so `result.messages` (the returned conversation
    // history) actually reflects it - previously this branch left
    // `finalText`/`result.text` set but never appended a corresponding
    // assistant message here (unlike the tool-call branch above, which
    // always pushes one), so any caller treating `result.messages` as
    // the authoritative conversation (e.g. to seed a follow-up turn)
    // silently lost the agent's own last reply whenever a turn ended
    // without a tool call - the common case for a plain chat exchange.
    if (result.text) {
      state.messages.push(withHostedCalls({ role: 'assistant', content: result.text }, result.hostedToolCalls));
    }
    state.finishReason = result.finishReason;
    return 'stop';
  }

  /**
   * LOU-X4: the step's text after the output guardrails (they check the final
   * reply, and every step's text when the run is iterated - a `stream()` -
   * before it is emitted), or the blocked run's result. `send()` / `execute()`
   * with listeners stream their model calls (M9) but are not iterated: only
   * the final reply is checked, as without listeners.
   */
  private static async guardOutput(
    options: ExecuteOptions,
    state: AgentRunState,
    { text, toolCalls }: GenerateResult
  ): Promise<string | ExecutionResult> {
    if (!text || (toolCalls?.length && !runEventsOf(options)?.iterated)) return text;
    const checked = await checkOutputGuardrails(options, text, state.messages);
    return 'tripped' in checked ? this.stopForGuardrail(options, state, checked.tripped) : checked.text;
  }

  /**
   * Calls provider.generate() for the next turn. Resolves to `undefined`
   * when the failure was instead folded into the conversation for the
   * model to react to (LOU-T4 `surfaceRetryableProviderErrors`), or
   * `'steered'` when `run.steer()` aborted the call before it emitted
   * anything (LOU-V10): its partial output is dropped.
   */
  private static async generateOrSurfaceError(
    options: ExecuteOptions,
    state: AgentRunState,
    tools: ToolDefinition[],
    agentSpanId: string
  ): Promise<GeneratedStep | 'steered' | ExecutionResult | undefined> {
    // N5b: the first call runs alongside the parallel input guardrails; their trip aborts it alone.
    const inputCheck = state.inputCheck;
    state.inputCheck = undefined;
    const steerSignal = options.inputQueue?.startCall();
    const callSignal = inputCheck ? (steerSignal ? AbortSignal.any([steerSignal, inputCheck.signal]) : inputCheck.signal) : steerSignal;
    const partial = { text: '' };
    let called = false;
    try {
      // Audit C4: a hook's side calls (the compaction summarizer) count in the run's usage and budgets.
      const sideGenerate = sideGenerator(options, agentSpanId, (measured) => recordStepUsage(state.usage, measured));
      const generateRequest = await prepareGenerateRequest(options, state.messages, tools, callSignal, sideGenerate);
      callSignal?.throwIfAborted();
      called = true;
      const generated = await generateInSpan(options, generateRequest, state.messages, agentSpanId, callSignal, inputCheck, partial);
      callSignal?.throwIfAborted();
      // Eve CORE-F15: a provider that ignored the signal still ends the run 'aborted', its late reply dropped.
      if (options.signal?.aborted) {
        recordStep(state, generated.measured);
        called = false;
        options.signal.throwIfAborted();
      }
      return generated;
    } catch (generateError) {
      // N5b: whatever else happened, a blocked input wins; nothing goes on before the checks settled.
      const blocked = await this.settleInputCheck(options, state, inputCheck);
      if (blocked) return blocked;
      // Eve CORE-F11: a call the run's signal stopped still costs its tokens, and keeps what it streamed.
      if (called && options.signal?.aborted) {
        recordStep(state, measureAbortedCall(options, state.messages, partial.text));
        if (partial.text) state.interruptedText = partial.text;
      }
      return this.foldOrThrowGenerateError(options, state, steerSignal, generateError);
    } finally {
      options.inputQueue?.endPhase();
    }
  }

  /**
   * The generate() failure path of {@link generateOrSurfaceError}: `'steered'`
   * when `run.steer()` aborted the call, `undefined` after the compacted
   * provider error was folded into the conversation for the model to react
   * to (LOU-T4 `surfaceRetryableProviderErrors`), and a throw for every
   * other outcome.
   */
  private static foldOrThrowGenerateError(
    options: ExecuteOptions,
    state: AgentRunState,
    steerSignal: AbortSignal | undefined,
    generateError: unknown
  ): 'steered' | undefined {
    if (steerSignal?.aborted && !options.signal?.aborted) {
      return 'steered';
    }
    // A cancellation is not a provider failure - never compact it or fold
    // it into the conversation for a retry. With `signal` (LOU-V1) the
    // loop turns it into an 'aborted' result; an AbortError thrown without
    // one (see isAbortError()) reaches the caller untouched.
    if (options.signal?.aborted || isAbortError(generateError)) {
      throw generateError;
    }

    // LOU-R13: a cassette mismatch (or an unreadable cassette raised by the
    // interception seam) is a test-fixture failure, not a provider failure.
    // It reaches the caller typed - compacting it would hide the cassette
    // path, the call number and the re-record hint behind a generic
    // CompactedLLMProviderError.
    if (isCassetteError(generateError)) {
      throw generateError;
    }

    // A file part the provider cannot send is rejected before any request:
    // it reaches the caller with its own code, LOUSHO_UNSUPPORTED_CONTENT.
    if (generateError instanceof SDKError && generateError.code === 'LOUSHO_UNSUPPORTED_CONTENT') {
      throw generateError;
    }

    const { compacted, error: compactedError } = compactGenerateError(
      generateError,
      options.provider.name
    );

    if (!shouldSurfaceToModel(options, compacted)) {
      // Non-actionable category ('auth-failure', 'unknown'), or the
      // opt-in flag is off: reject execute() cleanly, exactly like
      // before LOU-T4 - just with the small compacted error instead of
      // the raw provider error. runAgentLoop()'s catch block emits the
      // 'error' event for this, same as it does for every other thrown
      // error in the loop - no need to duplicate that here.
      throw compactedError;
    }

    // See providerErrorMessage() for why this is a tagged `user` message.
    state.messages.push(providerErrorMessage(compacted));

    runEventsOf(options)?.error(compactedError);

    state.lastSurfacedProviderError = compactedError;
    return undefined;
  }

  /**
   * N5b: waits for the parallel input guardrails (`check`, default the run's
   * pending ones) to settle. Resolves to the blocked run's result on a trip -
   * counting the cancelled call's usage only when the provider reported it -
   * or `undefined` when they passed or the run was aborted (the loop then ends
   * it as `'aborted'`). A check that threw rejects with its error.
   */
  private static async settleInputCheck(
    options: ExecuteOptions,
    state: AgentRunState,
    check: ParallelInputCheck | undefined = state.inputCheck
  ): Promise<ExecutionResult | undefined> {
    if (!check) return undefined;
    if (check === state.inputCheck) state.inputCheck = undefined;
    if (await check.verdict) return undefined;
    if (options.signal?.aborted) return undefined;
    if (!check.trip) throw check.error;
    const reported = check.response && !check.response.measured.estimated ? check.response.measured : undefined;
    if (reported) recordStep(state, reported);
    return this.stopForGuardrail(options, state, check.trip);
  }

  /**
   * Executes the tool calls of one assistant turn - concurrently up to
   * `toolConcurrency` (LOU-V3, see that option for the ordering contract) -
   * appending the results to the conversation in call order and
   * checkpointing as they are recorded. Resolves to the ExecutionResult to
   * return when the run pauses for approval or is aborted.
   */
  private static async runToolCalls(
    options: ExecuteOptions,
    state: AgentRunState,
    turn: Message,
    toolCalls: ToolCall[],
    agentSpanId: string
  ): Promise<ExecutionResult | undefined> {
    state.toolCalls.push(...toolCalls);

    // Add assistant message with tool calls (and LOU-V13: its signed reasoning)
    state.messages.push(turn);

    // LOU-U9: checkpoint the model's turn before any tool runs, so a crash
    // from here on resumes by running the calls - never by asking the
    // model again.
    await saveStepCheckpoint(options, state);

    return this.runBatch(options, state, toolCalls, agentSpanId);
  }

  /**
   * LOU-U7/U9: runs the tool calls of the last model turn that have no
   * result yet (left by a crash, or by an approval pause mid-batch), then
   * appends any input queued behind them. Resolves to 'continue', or the
   * ExecutionResult when the run pauses again or is aborted.
   */
  private static async runPendingToolCalls(
    options: ExecuteOptions,
    state: AgentRunState,
    agentSpanId: string
  ): Promise<'continue' | ExecutionResult> {
    const calls = state.pendingToolCalls;
    state.pendingToolCalls = [];
    const stopped = await this.runBatch(options, state, calls, agentSpanId);
    if (stopped) {
      return stopped;
    }
    state.messages.push(...state.queuedInput);
    state.queuedInput = [];
    return 'continue';
  }

  /**
   * Runs one batch of tool calls through the LOU-V3 scheduler, recording
   * results in call order and checkpointing as they are recorded.
   */
  private static async runBatch(
    options: ExecuteOptions,
    state: AgentRunState,
    turnCalls: ToolCall[],
    agentSpanId: string
  ): Promise<ExecutionResult | undefined> {
    const runEvents = runEventsOf(options);
    // N6: handoff calls are not run as tools; they are settled once the others are done.
    const { calls: toolCalls, handoffCalls } = splitHandoffCalls(options, turnCalls);
    // LOU-Y1: tool calls whose sub-agent paused for approval, in call order.
    const suspensions: SubagentSuspension[] = [];
    const batch = await runToolBatch(
      toolCalls,
      options.toolConcurrency ?? 'unbounded',
      {
        start: (toolCall) => {
          runEvents?.toolStart(toolCall);
          return this.startToolCall(options, state, toolCall, agentSpanId);
        },
        onComplete: (toolResult) => runEvents?.toolSettled(toolResult),
        record: (toolCall, outcome) => {
          pushToolResult(state, toolCall, outcome, options.maxToolResultChars);
          if (outcome.subagent) suspensions.push(outcome.subagent);
        },
        persist: () => saveStepCheckpoint(options, state),
      },
      // LOU-V10: a steer stops the batch from starting more calls; running ones finish.
      // Eve2-F5: the run's signal also ends the wait for a tool that ignores it.
      withSteerSignal(options.signal, options.inputQueue?.startBatch()),
      options.signal
    );
    options.inputQueue?.endPhase();

    // record() runs in completion order; the run pauses on the suspended
    // sub-agent that comes first in CALL order, so sort them back.
    const callOrder = new Map(toolCalls.map((call, index) => [call.id, index]));
    suspensions.sort((a, b) => (callOrder.get(a.toolCallId) ?? 0) - (callOrder.get(b.toolCallId) ?? 0));
    const stopped = this.settleToolBatch(options, state, batch, suspensions, handoffCalls);
    // A steer cut the batch short (its calls, the handoff calls too, were cancelled).
    if (stopped || handoffCalls.length === 0 || batch.unrecorded.length > 0) return stopped;
    return this.settleHandoffCalls(options, state, handoffCalls);
  }

  /**
   * N6: settles a step's handoff calls once its other calls are done. A call
   * whose gate (validation, hooks, permission rules) denied it settles with a
   * tool error; an `ask` pauses the run for approval exactly like a tool's
   * `ask`; the first cleared call switches the run to its target (taken by
   * the loop from `state.switched`).
   */
  private static async settleHandoffCalls(options: ExecuteOptions, state: AgentRunState, handoffCalls: ToolCall[]): Promise<ExecutionResult | undefined> {
    let gate: HandoffGate;
    try {
      gate = await takeHandoffCalls(options, state, handoffCalls);
    } catch (error) {
      // LOU-X4: a tool guardrail blocks a handoff call like any other call of the turn.
      if (error instanceof GuardrailError) return this.stopForGuardrail(options, state, error.guardrail);
      throw error;
    }
    if (gate.approval) {
      // Every other call of the turn already has its result; nothing waits behind the decision.
      return this.pauseForApproval(options, state, [gate.approval], []);
    }
    const honored = gate.honored;
    if (!honored) {
      await saveStepCheckpoint(options, state);
      return undefined;
    }
    const switched = await handOff(options, state, honored, (next) => extendRunOptions(next));
    const next = switched.options;
    const tools = runTools(next);
    assertHostedToolsSupported(next.hostedTools, next.agent, next.provider);
    state.messages = switched.messages;
    state.agentName = switched.marker.to;
    state.handoffs = (state.handoffs ?? 0) + 1;
    // LOU-W9.2: checkpoints and pauses from here on record the target, so a resume compares with it.
    state.fingerprint = undefined;
    if (next.sessionId && next.checkpointStore) await ensureFingerprint(next, state);
    const { toolCall } = honored;
    // The honored call settles like a tool call: post hooks may replace the routing result the target reads.
    await settleHonoredHandoff(options, state.messages, honored, switched.marker);
    runEventsOf(options)?.handoff({ ...switched.marker, toolCallId: toolCall.id });
    state.switched = { options: next, tools };
    await saveStepCheckpoint(next, state);
    return undefined;
  }

  /**
   * Turns a finished batch into the run's next move: abort (finished calls
   * keep their results, the rest are cancelled), reject with the first
   * fatal error, pause for approval, or carry on (`undefined`). N6: the
   * step's handoff calls are cancelled with the rest, or wait with the
   * calls left for after a pause.
   */
  private static settleToolBatch(
    options: ExecuteOptions,
    state: AgentRunState,
    batch: ToolBatchResult,
    suspensions: SubagentSuspension[],
    handoffCalls: ToolCall[]
  ): Promise<ExecutionResult> | undefined {
    if (options.signal?.aborted) {
      pushAbortedBatchResults(state, batch.unrecorded, undefined, options.maxToolResultChars);
      cancelHandoffCalls(state, handoffCalls, 'the run was aborted');
      return this.abortRun(options, state);
    }
    // LOU-X4: a tool guardrail blocked a call before it ran; the rest of the batch did not start.
    if (batch.failure?.error instanceof GuardrailError) {
      pushAbortedBatchResults(state, batch.unrecorded, 'a guardrail stopped the run', options.maxToolResultChars);
      cancelHandoffCalls(state, handoffCalls, 'a guardrail stopped the run');
      return this.stopForGuardrail(options, state, batch.failure.error.guardrail);
    }
    if (batch.failure) {
      throw batch.failure.error;
    }
    // N9b: a tool that needs sign-in pauses the run first; it runs again once the user signed in.
    const signIn = batch.unrecorded.find((call) => call.outcome?.signIn);
    if (signIn) {
      return this.pauseForSignIn(options, state, batch.unrecorded, signIn, suspensions, handoffCalls);
    }
    const suspension = settleSuspensions(state.messages, suspensions, false);
    if (batch.approvals.length > 0) {
      // Eve TOOLS-F12: the step pauses once, on every call that needs approval. Calls a steer kept from starting run after the decisions;
      // a sub-agent of the step that paused too pauses the run once they are decided.
      const waiting = new Set(batch.approvals.map(({ toolCall }) => toolCall));
      const remaining = batch.unrecorded.filter((call) => !waiting.has(call.toolCall)).map((call) => call.toolCall);
      return this.pauseForApproval(options, state, batch.approvals, [...remaining, ...handoffCalls], suspension);
    }
    // LOU-V10: what is left of a batch a steer stopped was not run.
    pushAbortedBatchResults(state, batch.unrecorded, 'the user steered the run to new input', options.maxToolResultChars);
    if (batch.unrecorded.length > 0) cancelHandoffCalls(state, handoffCalls, 'the user steered the run to new input');
    if (suspension) {
      const record = suspensionRecord(options, state, suspension);
      // N6: a handoff call of the step is settled once the sub-agent's approval is decided.
      if (handoffCalls.length > 0) record.snapshot.remainingToolCalls = handoffCalls;
      return this.savePause(options, state, record);
    }
    return undefined;
  }

  /**
   * Starts one tool call. `gate` settles once it passed its pre-execution
   * checks (or rejects with the error that stopped it); `done` settles with
   * its outcome.
   */
  private static startToolCall(
    options: ExecuteOptions,
    state: AgentRunState,
    toolCall: ToolCall,
    agentSpanId: string
  ): StartedToolCall {
    let openGate!: (prepared: PreparedToolCall) => void;
    let failGate!: (error: unknown) => void;
    const gate = new Promise<PreparedToolCall>((resolve, reject) => {
      openGate = resolve;
      failGate = reject;
    });
    const done = this.runToolCallInSpan(options, state, toolCall, agentSpanId, openGate);
    // Rejecting an already-resolved gate is a no-op.
    done.catch(failGate);
    return { gate, done };
  }

  /**
   * Runs one tool call inside a `tool.call` span parented to the run's
   * `agent.run` span.
   */
  private static runToolCallInSpan(
    options: ExecuteOptions,
    state: AgentRunState,
    toolCall: ToolCall,
    agentSpanId: string,
    onPrepared?: (prepared: PreparedToolCall) => void
  ): Promise<ToolCallOutcome> {
    const {
      agent,
      toolRegistry,
      onToolCall,
      onToolResult,
      sandbox = NoopSandbox,
      hooks,
      exporter,
      redactContent,
      signal,
    } = options;
    // Eve DUI-F5: the call's context gets the session's id, not a session turn's checkpoint key.
    const sessionId = options.contextSessionId ?? options.sessionId;

    const init = toolSpanInit({ id: toolCall.id, name: toolCall.function.name }, { agent, toolRegistry, sessionId: options.sessionId });
    return withSpan(
      exporter,
      init.name,
      init.attributes,
      async (toolSpan) => {
        const toolCallStart = Date.now();
        // LOU-Y1: a sub-agent started by this tool call inherits from this run.
        const scope: ToolCallScope = {
          runtime: options,
          toolCallId: toolCall.id,
          spanId: toolSpan.id,
          execute: (childOptions) => AgentExecutor.execute(childOptions),
        };
        // N14: a `run_code` call's script calls tools through this run's gate.
        if (toolCall.function.name === RUN_CODE_TOOL && codeModeOf(options)) {
          scope.callTool = nestedToolCaller({
            parentToolCallId: toolCall.id,
            parentSpanId: toolSpan.id,
            base: { agent, toolRegistry, onToolCall, onToolResult, sandbox, hooks, sessionId, principal: options.principal, metadata: options.metadata, messages: state.messages, onDelegatedUsage: (child) => mergeDelegatedUsage(state.usage, child) },
            signal,
            runtime: options,
            execute: scope.execute,
            tracing: { exporter, redactContent, captureContent: options.captureContent },
            concurrency: options.toolConcurrency ?? 'unbounded',
          });
        }
        const executed = await this.executeToolCall(
          toolCall,
          agent,
          toolRegistry,
          onToolCall,
          onToolResult,
          sandbox,
          hooks,
          sessionId,
          state.messages,
          signal,
          onPrepared,
          // LOU-V5: a delegated child's usage is added to this run's totals.
          (child) => mergeDelegatedUsage(state.usage, child),
          scope
        );
        const parsedArgs =
          executed.args === undefined
            ? parseToolArguments(toolCall, toolCall.function.arguments)
            : executed.args;
        recordToolOutcome(
          toolSpan,
          {
            args: parsedArgs,
            result: executed.result,
            error: executed.error,
            latencyMs: Date.now() - toolCallStart,
          },
          { redactContent, captureContent: resolveCaptureContent(options.captureContent) }
        );
        return executed;
      },
      agentSpanId,
      init.kind
    );
  }

  /**
   * N9b: pauses on the first call of the batch that needs sign-in. Calls
   * after it that finished are recorded; the ones that did not run (another
   * call needing sign-in, a call waiting on approval and what came after it)
   * run after the decision, like the rest of a turn paused on an approval.
   */
  private static pauseForSignIn(
    options: ExecuteOptions,
    state: AgentRunState,
    unrecorded: UnrecordedToolCall[],
    paused: UnrecordedToolCall,
    suspensions: SubagentSuspension[],
    handoffCalls: ToolCall[]
  ): Promise<ExecutionResult> {
    // N6: the step's handoff calls are settled after the decision, with the rest.
    const remaining: ToolCall[] = [...handoffCalls];
    for (const call of unrecorded) {
      if (call === paused) continue;
      const { outcome } = call;
      if (outcome && !outcome.requiresApproval && !outcome.signIn) {
        pushToolResult(state, call.toolCall, outcome, options.maxToolResultChars);
        if (outcome.subagent) suspensions.push(outcome.subagent);
      } else {
        remaining.push(call.toolCall);
      }
    }
    // One pause per run: a sub-agent that paused meanwhile is dropped (its result says so).
    settleSuspensions(state.messages, suspensions, true);
    return this.pauseForApproval(options, state, [{ toolCall: paused.toolCall, outcome: paused.outcome as ToolCallOutcome }], remaining);
  }

  /**
   * Persists the pending approvals (plus the snapshot resume.ts needs, with
   * the turn's not-yet-run calls - LOU-U7) and ends this execute() call
   * with an 'awaiting-approval' result. The checkpoint is marked
   * 'awaiting-approval' (LOU-U8) so new input cannot bypass the decision.
   * Eve TOOLS-F12: `calls` are every call of the step that waits on a
   * decision, in call order; several make one group (`approvalGroup`), each
   * with its own approval id, and run once all of them are decided.
   */
  private static async pauseForApproval(
    options: ExecuteOptions,
    state: AgentRunState,
    calls: Array<{ toolCall: ToolCall; outcome: ToolCallOutcome }>,
    remainingToolCalls: ToolCall[],
    heldSubagent?: SubagentSuspension
  ): Promise<ExecutionResult> {
    const { agent, approvalStore, sessionId, principal } = options;
    if (!approvalStore) {
      throw new ConfigurationError(
        `Tool '${calls[0].outcome.toolName}' requires approval but no approvalStore was provided to AgentExecutor.execute()`,
        'approvalStore',
        'LOUSHO_APPROVAL_STORE_MISSING'
      );
    }

    const pausedAt = Date.now();
    const group: PendingApproval[] = [];
    for (const [index, { toolCall, outcome: toolResult }] of calls.entries()) {
      // A millisecond apart, so a store lists the step's calls in call order (oldest first).
      const createdAt = new Date(pausedAt + index).toISOString();
      const id = newId();
      // TTL: an `ask` rule's `ttlMs` bounds its own pauses; else the run's default.
      const ttlMs = toolResult.approvalTtlMs ?? options.approvalTtlMs;
      group.push({
        id,
        toolCallId: toolCall.id,
        toolName: toolCall.function.name,
        args: toolResult.args || {},
        agentId: agent.id,
        createdAt,
        // A deadline past the last date a Date can hold (e.g. `1e20`) is no deadline at all.
        ...(typeof ttlMs === 'number' && Number.isFinite(ttlMs) && Date.now() + ttlMs <= MAX_DATE_MS && { expiresAt: new Date(Date.now() + ttlMs).toISOString() }),
        // N10b: whose call it is, for `approve` and channel `approvers`.
        ...(principal && { principal }),
        // N9b: a tool that needs sign-in pauses with the link to open.
        ...(toolResult.signIn && { kind: 'sign-in' as const, signIn: await signInRequest(toolResult.signIn, options.tokens, { approvalId: id, sessionId }) }),
      });
    }
    const snapshot: ExecutionSnapshot = {
      // The agent as configured: resume re-applies skills and sub-agents.
      agent: baseAgentOf(agent),
      // Queued input rides at the end; resume moves it behind the results.
      currentMessages: [...state.messages, ...state.queuedInput],
      pendingToolCall: group[0],
      steps: state.steps,
      sessionId,
      ...(options.contextSessionId !== undefined && { contextSessionId: options.contextSessionId }),
      remainingToolCalls,
      usage: structuredClone(state.usage),
      // N10b: the resumed run acts for this caller, whoever decides.
      ...(principal && { principal }),
      // LOU-R16: and its hooks keep seeing the run's metadata.
      ...(options.metadata !== undefined && { metadata: options.metadata }),
      ...(group.length > 1 && { approvalGroup: group.map((pending) => ({ pending })) }),
      ...(heldSubagent && { heldSubagent }),
    };
    return this.savePause(options, state, { pending: group[0], snapshot });
  }

  /**
   * Saves the approval record(s) of a pause (Eve TOOLS-F12: one per call of
   * its group) and ends this execute() call with an 'awaiting-approval'
   * result. The checkpoint is marked 'awaiting-approval' (LOU-U8) so new
   * input cannot bypass the decision.
   */
  private static async savePause(
    options: ExecuteOptions,
    state: AgentRunState,
    record: { pending: PendingApproval; snapshot: ExecutionSnapshot }
  ): Promise<ExecutionResult> {
    const { approvalStore } = options;
    const records = approvalRecords(record);
    const ids = records.map((entry) => entry.pending.id);
    // Approval first: a crash between the two writes then leaves a
    // resumable 'in-progress' checkpoint, never one naming a lost approval.
    if (approvalStore) {
      const fingerprint = record.snapshot.agentFingerprint ?? (await ensureFingerprint(options, state));
      for (const entry of records) {
        entry.snapshot.agentFingerprint ??= fingerprint;
        await approvalStore.save(entry.pending, entry.snapshot);
      }
    }
    await saveStepCheckpoint(options, state, 'awaiting-approval', ids, describeApproval(records[0].pending).kind);
    for (const entry of records) runEventsOf(options)?.approvalRequested(entry.pending);

    return {
      ...toExecutionResult(state, '', 'awaiting-approval'),
      approvalId: ids[0],
      approvalIds: ids,
    };
  }

  /**
   * Ends a run whose signal was aborted (LOU-V1): checkpoints the state so
   * far (when checkpointing is on, so the session can be resumed later)
   * and resolves with finishReason 'aborted'.
   */
  private static async abortRun(
    options: ExecuteOptions,
    state: AgentRunState
  ): Promise<ExecutionResult> {
    const timedOut = budgetOfAbort(options.signal);
    if (timedOut) return this.stopForBudget(options, state, timedOut);
    state.finishReason = 'aborted';
    options.inputQueue?.close();
    await saveStepCheckpoint(options, state);
    // The text the aborted call streamed is the result's text too (its tokens are already in `usage`).
    const interrupted = state.interruptedText;
    if (interrupted) {
      state.messages.push({ role: 'assistant', content: interrupted, metadata: { interrupted: true } });
      state.interruptedText = undefined;
    }

    return { ...toExecutionResult(state, interrupted || state.finalText, 'aborted'), abortReason: abortReasonOf(options.signal) };
  }

  /**
   * LOU-V6: ends a run whose budget tripped like `max-steps` (checkpointed
   * as finished), after a `budget.exceeded` event; throws
   * `BudgetExceededError` under `onExceeded: 'throw'`.
   */
  private static async stopForBudget(
    options: ExecuteOptions,
    state: AgentRunState,
    budget: BudgetExceeded
  ): Promise<ExecutionResult> {
    state.finishReason = 'budget-exceeded';
    runEventsOf(options)?.budgetExceeded(budget);
    if (state.budget?.mode(budget) === 'throw') {
      await saveStepCheckpoint(options, state, 'finished');
      throw new BudgetExceededError(budget);
    }
    return { ...(await this.finishRun(options, state)), budget };
  }

  /** LOU-X4: ends a blocked run like {@link stopForBudget}, after a `guardrail.tripped` event. */
  private static async stopForGuardrail(
    options: ExecuteOptions,
    state: AgentRunState,
    guardrail: GuardrailTrip
  ): Promise<ExecutionResult> {
    state.finishReason = 'guardrail';
    state.finalText = '';
    runEventsOf(options)?.guardrail({ type: 'guardrail.tripped', ...guardrail });
    if (options.guardrails?.onTripped === 'throw') {
      await saveStepCheckpoint(options, state, 'finished');
      throw new GuardrailError(guardrail);
    }
    return { ...(await this.finishRun(options, state)), guardrail };
  }

  /**
   * Ends a run that left the loop - the model stopped requesting tools,
   * or maxSteps was exhausted.
   */
  private static async finishRun(
    options: ExecuteOptions,
    state: AgentRunState,
    output?: Pick<ExecutionResult, 'object' | 'outputError' | 'outputRepaired'>
  ): Promise<ExecutionResult> {
    // LOU-T4: `maxSteps` was exhausted, but the very last thing that
    // happened was a surfaced-to-the-model provider failure (not a genuine
    // model stop/tool-calls turn) - every retry the model got a chance to
    // take failed the same way. Reject with that last compacted error
    // instead of silently returning a "successful-looking" ExecutionResult
    // (finishReason would otherwise read as a stale value from before the
    // failures started, misrepresenting what actually happened).
    if (state.lastSurfacedProviderError) {
      runEventsOf(options)?.error(state.lastSurfacedProviderError);
      throw state.lastSurfacedProviderError;
    }

    // The run has reached a terminal state (either the model stopped
    // requesting tools, or maxSteps was exhausted). LOU-U8: keep the
    // transcript, marked 'finished', so a later execute() call reusing this
    // sessionId continues the conversation with its new input instead of
    // resuming this run (or forgetting it).
    await saveStepCheckpoint(options, state, 'finished');

    return { ...toExecutionResult(state, state.finalText, state.finishReason), ...output };
  }

  /**
   * Execute a tool call (see toolCallExecution.ts). Kept as a positional,
   * static entry point the loop above calls into.
   */
  private static async executeToolCall(
    toolCall: ToolCall,
    agent: AgentConfig,
    toolRegistry?: ToolRegistry,
    onToolCall?: ExecuteOptions['onToolCall'],
    onToolResult?: ExecuteOptions['onToolResult'],
    sandbox: SandboxAdapter = NoopSandbox,
    hooks?: HookRegistry,
    sessionId?: string,
    messages: Message[] = [],
    signal?: AbortSignal,
    onPrepared?: (prepared: PreparedToolCall) => void,
    onDelegatedUsage?: ToolCallContext['onDelegatedUsage'],
    scope?: ToolCallScope
  ): Promise<ToolCallOutcome> {
    return runToolCall(
      toolCall,
      {
        agent,
        toolRegistry,
        onToolCall,
        onToolResult,
        sandbox,
        hooks,
        sessionId,
        // N10b: the run's principal (the scope's runtime is the run's options).
        principal: scope?.runtime.principal,
        // LOU-R16: the run's metadata, for the pre/post tool-call hooks.
        metadata: scope?.runtime.metadata,
        messages,
        signal,
        onDelegatedUsage,
        scope,
        // N13b: a generator tool's snapshots reach the run's events (the scope's runtime is the run's options).
        onToolPartial: scope && partialSink(scope.runtime),
      },
      onPrepared
    );
  }

  /**
   * Guards the options execute() truly cannot run without, throwing a
   * clear error naming the missing field plus a corrective one-line code
   * snippet - instead of the generic "Cannot read properties of
   * undefined" TypeError that would otherwise surface deep inside
   * runAgentLoop() (e.g. `provider.generate(...)` when `provider` is
   * undefined).
   */
  private static validateExecuteOptions(
    options: ExecuteOptions,
    caller = 'AgentExecutor.execute'
  ): void {
    if (!options || !options.provider) {
      throw new ConfigurationError(
        `${caller}: 'provider' is required. ` +
          "Example: AgentExecutor.execute({ agent, input, provider: myProvider })",
        'provider',
        'LOUSHO_CONFIG_MISSING_PROVIDER'
      );
    }
    if (!options.agent) {
      throw new ConfigurationError(
        `${caller}: 'agent' is required. ` +
          'Example: AgentExecutor.execute({ agent: AgentBuilder.create()...build(), input, provider })',
        'agent',
        'LOUSHO_CONFIG_MISSING_AGENT'
      );
    }
    if (options.input === undefined || options.input === null) {
      throw new ConfigurationError(
        `${caller}: 'input' is required. ` +
          "Example: AgentExecutor.execute({ agent, input: 'hello', provider })",
        'input',
        'LOUSHO_CONFIG_MISSING_INPUT'
      );
    }
    assertToolConcurrency(options.toolConcurrency, caller);
    assertMaxSteps(options.maxSteps, caller);
    assertMaxToolResultChars(options.maxToolResultChars, caller);
    assertMaxSubagentDepth(options.maxSubagentDepth, caller);
    assertToolSearchOptions(options.toolSearch, caller);
    assertOutputSchema(options.output);
  }
}
