/**
 * cyrb53: a fast 53-bit string hash, base-36 encoded.
 *
 * Shared by `channelSessionId()` (channels/defineChannel.ts, which appends
 * it to a sanitized session key to keep it unique) and `argsKey()`
 * (tools/approvalPolicies.ts, which hashes approval args). Not a public API
 * (not re-exported from utils/index.ts); for hashing, not for security.
 */
export function cyrb53(text: string): string {
  let h1 = 0xdeadbeef;
  let h2 = 0x41c6ce57;
  for (let i = 0; i < text.length; i++) {
    const c = text.charCodeAt(i);
    h1 = Math.imul(h1 ^ c, 2654435761);
    h2 = Math.imul(h2 ^ c, 1597334677);
  }
  h1 = Math.imul(h1 ^ (h1 >>> 16), 2246822507) ^ Math.imul(h2 ^ (h2 >>> 13), 3266489909);
  h2 = Math.imul(h2 ^ (h2 >>> 16), 2246822507) ^ Math.imul(h1 ^ (h1 >>> 13), 3266489909);
  return (4294967296 * (2097151 & h2) + (h1 >>> 0)).toString(36);
}
