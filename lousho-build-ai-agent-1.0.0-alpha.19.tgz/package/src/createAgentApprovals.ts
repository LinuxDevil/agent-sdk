/**
 * Approvals for createAgent() agents (LOU-D21): a thin layer over an
 * ApprovalStore and resumeAfterApproval(). It records which approvals the
 * agent paused on (for `agent.approvals.list()`), continues a paused session
 * when its approval is resolved, and - with an `approve` callback - decides
 * each pause at once by resuming the run with the callback's answer.
 */

import { approvalExpired, describeApproval, markAutomaticDecision, oldestFirst, type ApprovalDecision, type ApprovalStore, type PendingApproval } from './execution/ApprovalGate';
import type { ExecutionResult } from './execution/AgentExecutor';
import type { AgentEvent } from './execution/agentEvents';
import type { AgentRun } from './execution/agentRun';
import type { CheckpointStore } from './execution/checkpoint';
import { ConfigurationError, SDKError, SessionAwaitingApprovalError } from './execution/errors';
import type { InputQueue } from './execution/inputQueue';
import { streamSessionTurn } from './session/sessionStream';
import { AgentSession, type SessionOptions, type SessionRunner, type SessionSpawner, type SessionStreamRunner } from './session/AgentSession';
import type { PermissionOptions } from './execution/permissions';
import type { Principal } from './auth/types';

/** N4: the mode a continued run uses: the paused session's (a getter), or undefined for the agent's. */
type ResumeMode = PermissionOptions['permissionMode'];

/**
 * Options of `agent.approvals.resolve()` / `answer()` / `streamResolve()` /
 * `streamAnswer()`.
 */
export interface ResolveApprovalOptions {
  signal?: AbortSignal;
  /**
   * N10b: who decides (route auth's principal, a channel's clicking user).
   * The approved tool sees it as `ctx.approval.by`; the run itself goes on
   * as the principal it paused with, never as this one (docs/auth.md).
   */
  principal?: Principal;
}

/**
 * Decides a tool call that needs approval without pausing the run: `true`
 * runs the tool, `false` gives the model a rejection as the tool's result.
 * A string approves with that string as the note - for an `ask_question`
 * call (`request.kind === 'question'`), it is the answer (LOU-X9). It is
 * never asked about a sign-in (`kind: 'sign-in'`, N9b): only the user can sign in.
 * `request.principal` (N10b) is who the paused run acts for.
 *
 * The literal `'defer'` does not decide: the call stays pending (listed by
 * `agent.approvals.list()`, resolvable by `agent.approvals.resolve()`) and
 * the run surfaces the pause - `send()` resolves with
 * `finishReason: 'awaiting-approval'`, exactly as if the callback had never
 * been asked. An approver can thereby decide the calls it trusts and hand
 * the rest to a human. (`'defer'` is reserved: a note that is exactly the
 * string `'defer'` defers instead of approving.)
 *
 * @example
 * ```ts
 * const approve: ApproveToolCall = ({ toolName, args }) => toolName !== 'send_email' || args.to === 'me@example.com';
 * const answer: ApproveToolCall = (request) => (request.kind === 'question' ? 'Lisbon' : true);
 * const triage: ApproveToolCall = ({ toolName }) => (toolName === 'lookup' ? true : 'defer'); // humans decide the rest
 * ```
 */
export type ApproveToolCall = (request: PendingApproval) => boolean | 'defer' | (string & {}) | Promise<boolean | 'defer' | (string & {})>;

/** `agent.approvals`: the tool calls a `createAgent()` agent is paused on, and how to decide them. */
export interface AgentApprovals {
  /**
   * Approvals that are not decided yet, oldest first: the ones this agent
   * paused on in this process and - through an `approvalStore` that
   * implements `list` (the file, SQLite, KV and in-memory stores do) - the
   * ones the store holds from another process or from before a restart. A
   * pause of this process that the store no longer holds (another process
   * resolved it) is left out. TTL: an entry past its `expiresAt` stays listed
   * until decided - the run is still paused - but deciding it denies the call.
   */
  list(): Promise<PendingApproval[]>;
  /**
   * The pending approval `id`, without deciding it. With an `approvalStore`
   * that implements `load`, the store answers first - a pause another process
   * resolved is `undefined` here too, and a pause saved before a restart is
   * found (the request's facts as it was recorded, so a
   * channel's function `approvers` sees the same input then as now, #280).
   * `undefined` when `id` is unknown or already resolved.
   */
  get(id: string): Promise<PendingApproval | undefined>;
  /**
   * Approves or rejects a paused tool call (`note` is passed to the model
   * with a rejection) and continues the run, resolving with the continued
   * run's result - which may pause again. A run paused inside
   * `agent.session()` continues in that session. Throws when `id` is unknown
   * or already resolved. TTL: a pause past its `expiresAt` is denied
   * ('approval expired') even when `approved: true` is passed - an expired
   * approval never runs its tool.
   *
   * @example
   * ```ts
   * const result = await agent.approvals.resolve({ id: paused.approvalId!, approved: true });
   * ```
   */
  resolve(decision: ApprovalDecision, options?: ResolveApprovalOptions): Promise<ExecutionResult>;
  /**
   * Eve TOOLS-F12: decides several pending approvals in one call, in the
   * order given - typically every call of a step that paused on several
   * (`result.approvalIds`). Each decision is `resolve()`'s (`args` to approve
   * with edits, `remember`); the step's approved calls run once the last of
   * its calls is decided, and the result is that of the last decision -
   * still `'awaiting-approval'` (listing what is left in `approvalIds`) when
   * some call of the step is not decided yet. Throws like `resolve()` on the
   * first decision that fails; the ones before it stay made.
   *
   * @example
   * ```ts
   * const result = await agent.approvals.resolveAll(
   *   paused.approvalIds!.map((id) => ({ id, approved: true }))
   * );
   * ```
   */
  resolveAll(decisions: readonly ApprovalDecision[], options?: ResolveApprovalOptions): Promise<ExecutionResult>;
  /**
   * Answers a paused `ask_question` call (LOU-X9): the same as
   * `resolve({ id, approved: true, note: answer })`. The model gets
   * `{ answer, option? }` as the tool's result.
   *
   * @example
   * ```ts
   * const result = await agent.approvals.answer({ id: paused.approvalId!, answer: 'Lisbon' });
   * ```
   */
  answer(reply: { id: string; answer: string }, options?: ResolveApprovalOptions): Promise<ExecutionResult>;
  /**
   * LOU-V14: like `resolve()`, but streams the continued run as the
   * `AgentRun` that `agent.stream()` returns (see docs/streaming.md). Its
   * `result` is what `resolve()` resolves with, except that, like
   * `stream()`, it ends at the next pause even with an `approve` callback.
   *
   * @example
   * ```ts
   * for await (const event of agent.approvals.streamResolve({ id: paused.approvalId!, approved: true })) {
   *   if (event.type === 'text.delta') process.stdout.write(event.text);
   * }
   * ```
   */
  streamResolve(decision: ApprovalDecision, options?: ResolveApprovalOptions): AgentRun;
  /** LOU-V14: `answer()`, streamed like `streamResolve()`. */
  streamAnswer(reply: { id: string; answer: string }, options?: ResolveApprovalOptions): AgentRun;
}

/**
 * resumeAfterApproval() bound to an agent's registry, provider and options;
 * `checkpointStore` is the paused session's, when its turns are checkpointed,
 * `permissionMode` (N4) the session's mode and `approver` (N10b) who decided.
 */
type ResumeRun = (
  store: ApprovalStore,
  decision: ApprovalDecision,
  signal?: AbortSignal,
  checkpointStore?: CheckpointStore,
  permissionMode?: ResumeMode,
  approver?: Principal,
  /** LOU-R18: the paused session's on() forwarder, when the run continues in one. */
  onAgentEvent?: (event: AgentEvent) => void
) => Promise<ExecutionResult>;

/** {@link ResumeRun}, streamed (LOU-V14); `inputQueue` is what `run.enqueue()` pushes to. */
type StreamResumeRun = (
  store: ApprovalStore,
  decision: ApprovalDecision,
  signal?: AbortSignal,
  checkpointStore?: CheckpointStore,
  inputQueue?: InputQueue,
  permissionMode?: ResumeMode,
  approver?: Principal,
  /** LOU-R18: the paused session's on() forwarder, when the run continues in one. */
  onAgentEvent?: (event: AgentEvent) => void
) => AgentRun;

/** A session whose paused turn can be continued by `agent.approvals.resolve()`. */
class ApprovalSession extends AgentSession {
  /** Set by createAgentApprovals(): binds an approval id to this session. */
  binds?: (approvalId: string) => void;

  /**
   * coding-agent F2: finding a paused turn binds it - the natural
   * "check pending(), then resolve()" flow then continues in this session
   * instead of falling back to a session-less resume.
   */
  protected override pausedTurnFound(approvalId: string): void {
    this.binds?.(approvalId);
  }

  /** Set by createAgentApprovals(): withdraws approvals from the agent's approval store. */
  withdraws?: (approvalIds: string[]) => Promise<void>;

  /** A paused turn `discardPending()` dropped: its approvals are withdrawn, so they are neither listed nor decided. */
  protected override async pendingTurnDiscarded(approvalIds: string[]): Promise<void> {
    await this.withdraws?.(approvalIds);
  }

  /**
   * Eve DUR-F6: a checkpointed session turn paused at `pausedAt`
   * (`<id>.turn-<n>`) can only be continued while its checkpoint exists - it
   * holds the turn until it finishes. When it is gone (pruned, deleted) the
   * resume would run the approved tool and then have nothing to commit to, so
   * fail first, before the tool runs.
   */
  async assertTurnKept(approvalId: string, pausedAt: string | undefined): Promise<void> {
    const { checkpointStore } = this;
    if (!checkpointStore || !pausedAt?.startsWith(`${this.id}.turn-`)) return;
    if (await checkpointStore.load(pausedAt)) return;
    throw new SDKError(
      `Approval '${approvalId}' belongs to session '${this.id}', but its paused turn ('${pausedAt}') is no longer stored ` +
        '(pruned or deleted), so it cannot be continued and the tool was not run.',
      'LOUSHO_APPROVAL_ORPHANED'
    );
  }

  resolveWith(
    next: (checkpointStore?: CheckpointStore, permissionMode?: ResumeMode, onAgentEvent?: (event: AgentEvent) => void) => Promise<ExecutionResult>,
    before?: () => Promise<void>
  ): Promise<ExecutionResult> {
    return this.continueTurn(async () => {
      await before?.();
      return next(this.checkpointStore, this.currentPermissionMode, this.turnEvents);
    });
  }

  /** LOU-V14: `resolveWith()`, streamed: `run.done` comes once the session has recorded the turn. */
  streamResolveWith(
    next: (
      checkpointStore: CheckpointStore | undefined,
      signal: AbortSignal,
      inputs: InputQueue,
      permissionMode: ResumeMode,
      onAgentEvent?: (event: AgentEvent) => void
    ) => AgentRun,
    signal?: AbortSignal,
    before?: () => Promise<void>
  ): AgentRun {
    return streamSessionTurn(
      (runSignal, started, inputs) =>
        this.continueTurn(async () => {
          await before?.();
          const run = next(this.checkpointStore, runSignal, inputs, this.currentPermissionMode, this.turnEvents);
          started(run);
          return run.result;
        }),
      signal
    );
  }
}

/** Wires an agent's approval store, `approve` callback and resume function together. */
export function createAgentApprovals(options: {
  store: ApprovalStore;
  approve?: ApproveToolCall;
  resume: ResumeRun;
  streamResume: StreamResumeRun;
  /**
   * The agent's checkpoint store, when it has one (LOU-D30). Used to tell a
   * paused *session turn* apart from a `send(msg, { sessionId })` run when
   * `resolve()` must rebind a session it never saw (see `coldSession`).
   */
  checkpoints?: CheckpointStore;
  /**
   * Opens the agent's session `id` (a fresh `agent.session({ id })`). Lets
   * `resolve()`/`streamResolve()` continue a paused session turn inside its
   * session even when that session was never opened in this process - without
   * it such a resolve ran outside the session and the turn was never recorded.
   */
  openSession?: (id: string) => AgentSession;
}) {
  const { approve, resume, streamResume } = options;
  const pending = new Map<string, PendingApproval>();
  const sessions = new Map<string, ApprovalSession>();
  /**
   * Session factory captured from `session()` calls (its `spawn` argument is
   * the agent's session factory): the fallback opener when `openSession` was
   * not wired - it only exists once this process opened a session itself.
   */
  let sessionSpawner: SessionSpawner | undefined;
  // A1: the session each pause belongs to, kept until the pause is claimed (unlike `sessions`, which a decision clears first).
  const sessionIds = new Map<string, string>();
  // Eve TOOLS-F12: the calls the `approve` callback deferred, so deciding another call of their step does not ask it again.
  const deferred = new Set<string>();
  const bind = (id: string, session: ApprovalSession) => {
    sessions.set(id, session);
    sessionIds.set(id, session.id);
  };
  const withSession = (request: PendingApproval): PendingApproval => {
    const sessionId = sessionIds.get(request.id);
    return sessionId === undefined ? request : { ...request, sessionId };
  };
  const store: ApprovalStore = {
    async save(raw, snapshot) {
      // LOU-X9: an `ask_question` call is recorded as `kind: 'question'`.
      const request = describeApproval(raw);
      await options.store.save(request, snapshot);
      pending.set(request.id, request);
    },
    async resolve(id) {
      const record = await options.store.resolve(id);
      pending.delete(id);
      sessionIds.delete(id);
      return record;
    },
    // Read without claiming: a resumed run binds its memory to the scope the paused one had.
    ...(options.store.load && { load: (id: string) => options.store.load!(id) }),
  };

  /**
   * The `approve` callback's verdict on `request`, or `false` once its
   * `expiresAt` (TTL) passes - an expired pause resumes as a denial
   * (`approval expired`), never with a stale approval, whatever the callback
   * answers later.
   */
  async function decide(request: PendingApproval): Promise<boolean | string> {
    if (!approve) return false;
    const expiresAt = request.expiresAt === undefined ? undefined : Date.parse(request.expiresAt);
    if (expiresAt === undefined || Number.isNaN(expiresAt)) return approve(request);
    if (approvalExpired(request)) return false;
    const left = expiresAt - Date.now();
    let timer: ReturnType<typeof setTimeout> | undefined;
    try {
      return await Promise.race([
        approve(request),
        new Promise<false>((resolve) => {
          timer = setTimeout(() => resolve(false), left);
          // The deadline alone must not keep the process alive.
          (timer as { unref?: () => void }).unref?.();
        }),
      ]);
    } finally {
      if (timer !== undefined) clearTimeout(timer);
    }
  }

  /** With an `approve` callback, decides every pause until the run finishes. */
  async function settle(
    result: ExecutionResult,
    signal?: AbortSignal,
    checkpointStore?: CheckpointStore,
    permissionMode?: ResumeMode,
    onAgentEvent?: (event: AgentEvent) => void
  ): Promise<ExecutionResult> {
    let current = result;
    for (;;) {
      if (!approve || current.finishReason !== 'awaiting-approval') return current;
      // Eve TOOLS-F12: each call of a step paused on several is asked about, in call order.
      const ids = current.approvalIds ?? (current.approvalId ? [current.approvalId] : []);
      // N9b: only the user can sign in, so a sign-in pause is never decided by `approve`.
      const request = ids.map((id) => pending.get(id)).find((entry) => entry !== undefined && entry.kind !== 'sign-in' && !deferred.has(entry.id));
      if (!request) return current;
      const verdict = await decide(request);
      // A 'defer' verdict is not a decision: the approval stays pending and
      // the paused result is surfaced as it is, for the human path to resolve.
      if (verdict === 'defer') {
        deferred.add(request.id);
        continue;
      }
      // Eve TOOLS-F19: the callback's decision, which `once()` does not remember.
      const decision = markAutomaticDecision(typeof verdict === 'string' ? { id: request.id, approved: true, note: verdict } : { id: request.id, approved: verdict });
      current = await resume(store, decision, signal, checkpointStore, permissionMode, undefined, onAgentEvent);
    }
  }

  function inSession(session: ApprovalSession | undefined, result: ExecutionResult): ExecutionResult {
    if (session && result.finishReason === 'awaiting-approval' && result.approvalId) {
      // Eve TOOLS-F12: every call the step waits on continues this session.
      for (const id of result.approvalIds ?? [result.approvalId]) bind(id, session);
    }
    return result;
  }

  /** `run`, with a pause it reports (as an event or in its result) bound to `session`. */
  function inSessionRun(session: ApprovalSession, run: AgentRun): AgentRun {
    return {
      runId: run.runId,
      result: run.result.then((result) => inSession(session, result)),
      enqueue: (input) => run.enqueue(input),
      steer: (input) => run.steer(input),
      async *[Symbol.asyncIterator]() {
        for await (const event of run) {
          if (event.type === 'approval.requested') bind(event.approvalId, session);
          yield event;
        }
      },
    };
  }

  /** N9b: a sign-in pause approved too early stays paused, and stays bound to its session. */
  function keepPendingSession(id: string, session: ApprovalSession | undefined, error: unknown): void {
    if (session && error instanceof Error && error.name === 'SignInPendingError') bind(id, session);
  }

  /**
   * The session a paused run belongs to, for a `resolve()`/`streamResolve()`
   * made after a restart (or by a caller that never opened the session): the
   * `sessions` map only knows pauses this process made or ran into. Without
   * this, the resume ran outside the session - the 'finished' checkpoint it
   * left behind was never committed to the transcript, which read as if the
   * whole turn had been deleted (coding-agent F1).
   *
   * The pause record's `snapshot.sessionId` is read WITHOUT claiming it:
   * `<id>.turn-<n>` means a durable session turn (the session's id is `<id>`);
   * a bare `<id>` with no checkpoint under it is a session turn that ran
   * without checkpointing (a `send(msg, { sessionId })` run of the same id
   * would have left its own checkpoint). Returns `undefined` - falling back
   * to the old session-less resume - when no opener exists or the pause was
   * not a session turn.
   */
  async function coldSession(approvalId: string): Promise<ApprovalSession | undefined> {
    const spawn = sessionSpawner;
    const open = options.openSession ?? (spawn && ((id: string) => spawn({ id })));
    if (!open || !options.store.load) return undefined;
    const record = await options.store.load(approvalId);
    const pausedAt = record?.snapshot.sessionId;
    if (!pausedAt) return undefined;
    const turn = /^([A-Za-z0-9_-]{1,128})\.turn-\d+$/.exec(pausedAt);
    let sessionId: string | undefined;
    if (turn) {
      sessionId = turn[1];
    } else if (options.checkpoints && (await options.checkpoints.load(pausedAt)) === null) {
      sessionId = pausedAt;
    }
    if (!sessionId) return undefined;
    const opened = open(sessionId);
    return opened instanceof ApprovalSession ? opened : undefined;
  }

  /** Eve DUR-F6: fails with `LOUSHO_APPROVAL_ORPHANED` when the session turn the pause belongs to is gone. */
  async function turnKept(approvalId: string, session: ApprovalSession): Promise<void> {
    const record = await options.store.load?.(approvalId);
    try {
      await session.assertTurnKept(approvalId, record?.snapshot.sessionId);
    } catch (error) {
      // The turn is gone for good: withdraw the approval, so it is no longer listed and every later resolve() is not refused again.
      if (error instanceof SDKError && error.code === 'LOUSHO_APPROVAL_ORPHANED') await store.resolve(approvalId);
      throw error;
    }
  }

  // N10b: `principal` is the approver of this decision only; the `approve` callback's later decisions have none.
  function resolve(decision: ApprovalDecision, { signal, principal }: ResolveApprovalOptions = {}): Promise<ExecutionResult> {
    deferred.delete(decision.id);
    let session = sessions.get(decision.id);
    sessions.delete(decision.id);
    const resolved = (async () => {
      session ??= await coldSession(decision.id);
      const next = async (checkpointStore?: CheckpointStore, permissionMode?: ResumeMode, onAgentEvent?: (event: AgentEvent) => void) =>
        inSession(
          session,
          await settle(await resume(store, decision, signal, checkpointStore, permissionMode, principal, onAgentEvent), signal, checkpointStore, permissionMode, onAgentEvent)
        );
      const kept = session;
      return kept ? kept.resolveWith(next, () => turnKept(decision.id, kept)) : next();
    })();
    return resolved.catch((error: unknown) => {
      keepPendingSession(decision.id, session, error);
      throw error;
    });
  }

  function streamResolve(decision: ApprovalDecision, { signal, principal }: ResolveApprovalOptions = {}): AgentRun {
    deferred.delete(decision.id);
    const bound = sessions.get(decision.id);
    sessions.delete(decision.id);
    if (!bound) {
      // The pause may belong to a session this process never opened: find it
      // before the resumed run starts (resolve() does the same lookup).
      return streamSessionTurn(async (runSignal, started, inputs) => {
        const session = await coldSession(decision.id);
        if (session) {
          const run = session.streamResolveWith(
            (checkpointStore, innerSignal, _innerInputs, permissionMode, onAgentEvent) =>
              inSessionRun(session, streamResume(store, decision, innerSignal, checkpointStore, inputs, permissionMode, principal, onAgentEvent)),
            runSignal,
            () => turnKept(decision.id, session)
          );
          started(run);
          run.result.catch((error: unknown) => keepPendingSession(decision.id, session, error));
          return run.result;
        }
        const run = streamResume(store, decision, runSignal, undefined, inputs, undefined, principal);
        started(run);
        return run.result;
      }, signal);
    }
    const run = bound.streamResolveWith(
      (checkpointStore, runSignal, inputs, permissionMode, onAgentEvent) =>
        inSessionRun(bound, streamResume(store, decision, runSignal, checkpointStore, inputs, permissionMode, principal, onAgentEvent)),
      signal,
      () => turnKept(decision.id, bound)
    );
    run.result.catch((error: unknown) => keepPendingSession(decision.id, bound, error));
    return run;
  }

  /**
   * Eve DUI-F15: forgets a pause of this process that the store no longer
   * holds - another process (or agent object) resolved it.
   */
  const forget = (id: string) => {
    deferred.delete(id);
    pending.delete(id);
    sessionIds.delete(id);
    sessions.delete(id);
  };

  /** This process's pauses the store still holds (all of them when it cannot `load`). */
  async function livePending(): Promise<PendingApproval[]> {
    const { load } = options.store;
    const local = [...pending.values()];
    if (!load) return local;
    const held = await Promise.all(local.map(async (entry) => ((await load.call(options.store, entry.id)) ? entry : undefined)));
    return local.filter((entry, index) => {
      if (held[index]) return true;
      forget(entry.id);
      return false;
    });
  }

  const approvals: AgentApprovals = {
    // Eve TOOLS-F13: a store that can `list` adds the pauses other processes (or this one before a restart) saved.
    list: async () => {
      const local = await livePending();
      if (!options.store.list) return local.map(withSession);
      const merged = new Map(local.map((entry) => [entry.id, entry]));
      for (const entry of await options.store.list()) {
        if (!merged.has(entry.id)) merged.set(entry.id, describeApproval(entry));
      }
      return oldestFirst([...merged.values()]).map(withSession);
    },
    // #280: the durable store answers too, so a pause this process did not make is found again.
    // Eve DUI-F15: a store that can `load` is asked first, so a pause resolved elsewhere is not reported.
    get: async (id) => {
      const { load } = options.store;
      if (!load) {
        const found = pending.get(id);
        return found === undefined ? undefined : withSession(found);
      }
      const record = await load.call(options.store, id);
      if (!record) {
        if (pending.has(id)) forget(id);
        return undefined;
      }
      return withSession(pending.get(id) ?? describeApproval(record.pending));
    },
    resolve,
    // Eve TOOLS-F12: one decision after the other; the last one runs the step.
    resolveAll: async (decisions, resolveOptions) => {
      if (decisions.length === 0) throw new ConfigurationError('agent.approvals.resolveAll() needs at least one decision.', 'decisions');
      let result: ExecutionResult | undefined;
      for (const decision of decisions) result = await resolve(decision, resolveOptions);
      return result as ExecutionResult;
    },
    answer: ({ id, answer }, resolveOptions) => resolve({ id, approved: true, note: answer }, resolveOptions),
    streamResolve,
    streamAnswer: ({ id, answer }, resolveOptions) => streamResolve({ id, approved: true, note: answer }, resolveOptions),
  };

  return {
    /** The store to run with: the agent's store, recording what is pending. */
    store,
    approvals,
    settle,
    /** A session of the agent; `spawn` creates its forks (N3a), by default another session with the same `run` / `stream`. */
    session(run: SessionRunner, stream: SessionStreamRunner, sessionOptions?: SessionOptions, spawn?: SessionSpawner): AgentSession {
      // `spawn` is the agent's session factory (agentSession passes it): keep
      // one around so a resolve() that never saw the pause can open the
      // session it belongs to (coldSession).
      if (spawn) sessionSpawner ??= spawn;
      const session: ApprovalSession = new ApprovalSession(
        async (input, signal, turn, call) => {
          try {
            return inSession(session, await settle(await run(input, signal, turn, call), signal, turn?.checkpointStore, turn?.permissionMode));
          } catch (error) {
            // A checkpointed turn found paused (e.g. after a restart): resolving it continues this session.
            if (error instanceof SessionAwaitingApprovalError && error.approvalId) bind(error.approvalId, session);
            throw error;
          }
        },
        sessionOptions,
        (input, signal, turn, call) => inSessionRun(session, stream(input, signal, turn, call)),
        spawn ?? ((forkOptions) => this.session(run, stream, forkOptions))
      );
      session.binds = (approvalId) => bind(approvalId, session);
      session.withdraws = async (approvalIds) => {
        for (const id of approvalIds) await store.resolve(id);
      };
      return session;
    },
  };
}
